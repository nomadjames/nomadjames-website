#!/usr/bin/env python3
"""Render CP-004 with Live-style menu and dial chrome."""
from __future__ import annotations

import html
import json
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parents[1]
PATCH_PATH = ROOT / 'max' / 'cymbal-phrase.maxpat'
HTML_PATH = ROOT / 'qa' / 'cp004-ui-preview.html'
PNG_PATH = ROOT / 'qa' / 'cp004-ui-preview.png'
SCALE = 3
CANVAS = (150 * SCALE, 145 * SCALE)


def load_font(size: int, bold: bool = False):
    name = 'DejaVuSans-Bold.ttf' if bold else 'DejaVuSans.ttf'
    for directory in ('/usr/share/fonts/truetype/dejavu', '/usr/share/fonts/truetype/liberation2'):
        path = Path(directory) / name
        if path.exists():
            return ImageFont.truetype(str(path), size)
    return ImageFont.load_default()


def boxes(patch: dict) -> list[dict]:
    return [entry['box'] for entry in patch['boxes'] if entry['box'].get('presentation') == 1]


def scaled(rect: list[float]) -> tuple[int, int, int, int]:
    return tuple(round(value * SCALE) for value in rect)  # type: ignore[return-value]


def label_value(item: dict) -> str:
    if item['maxclass'] == 'comment':
        return str(item.get('text', ''))
    value = item.get('saved_attribute_attributes', {}).get('valueof', {})
    if item['maxclass'] == 'live.menu':
        enum = value.get('parameter_enum', [])
        initial = int(value.get('parameter_initial', [0])[0])
        return str(enum[initial]) if enum else '—'
    if item['maxclass'] == 'live.dial':
        return f"{float(value.get('parameter_initial', [0])[0]):.1f}%"
    return ''


def parameter_shortname(item: dict) -> str:
    return str(item.get('saved_attribute_attributes', {}).get('valueof', {}).get('parameter_shortname', ''))


def css_item(item: dict) -> str:
    x, y, width, height = scaled(item['presentation_rect'])
    ident = html.escape(item['id'], quote=True)
    cls = item['maxclass'].replace('.', '-')
    text = html.escape(label_value(item))
    extra = ''
    inline = ''
    if item['maxclass'] == 'comment' and item['id'] == 'new-phrase-label':
        extra = ' small'
    if item['maxclass'] == 'panel' and item['id'] == 'dice-face':
        extra = ' dice-face'
    if item['maxclass'] == 'panel' and item['id'].startswith('dice-pip-'):
        extra = ' dice-pip'
    if item['maxclass'] == 'button':
        extra = ' action-button'
    if item['maxclass'] == 'comment' and item['id'] != 'new-phrase-label':
        size = round(float(item.get('fontsize', 7.0)) * SCALE)
        align = 'center' if item.get('textjustification') == 1 else 'left'
        inline = f';font-size:{size}px;text-align:{align}'
    if item['maxclass'] == 'live.dial':
        name = html.escape(parameter_shortname(item))
        return (
            f'<div id="{ident}" class="item {cls}" style="left:{x}px;top:{y}px;width:{width}px;height:{height}px" '
            f'data-source-rect="{item["presentation_rect"]}"><span class="dial-knob"></span>'
            f'<span class="dial-name">{name}</span><span class="dial-value">{text}</span></div>'
        )
    return f'<div id="{ident}" class="item {cls}{extra}" style="left:{x}px;top:{y}px;width:{width}px;height:{height}px{inline}" data-source-rect="{item["presentation_rect"]}">{text}</div>'


def render_html(items: list[dict]) -> str:
    content = '\n'.join(css_item(item) for item in items)
    return f'''<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Cymbal Phrase CP-004 UI Preview</title>
<style>
* {{ box-sizing: border-box; }}
html, body {{ margin: 0; width: 450px; height: 435px; background: #101113; }}
body {{ overflow: hidden; font-family: Arial, sans-serif; }}
#presentation {{ position: relative; width: 450px; height: 435px; background: #25272b; color: #f1f3f4; border: 3px solid #08090a; }}
.item {{ position: absolute; overflow: hidden; }}
.comment {{ padding: 0 6px; color: #b8bec6; font-size: 21px; line-height: 30px; font-weight: 700; letter-spacing: .3px; white-space: nowrap; }}
.live-menu {{ display: flex; align-items: center; padding: 0 9px; color: #f5f6f7; background: #444951; border: 3px solid #69717b; border-radius: 6px; font-size: 20px; line-height: 42px; white-space: nowrap; }}
.live-dial {{ color: #f5f6f7; text-align: center; }}
.dial-knob {{ position: absolute; left: 35px; top: 5px; width: 62px; height: 62px; background: #515b66; border: 3px solid #7c8793; border-radius: 50%; }}
.dial-knob::after {{ content: ''; position: absolute; left: 50%; top: 8px; width: 5px; height: 25px; background: #d49a5d; border-radius: 3px; transform: translateX(-50%); }}
.dial-name, .dial-value {{ position: absolute; left: 0; width: 100%; white-space: nowrap; overflow: hidden; }}
.dial-name {{ top: 75px; font-size: 19px; line-height: 27px; }}
.dial-value {{ top: 105px; color: #b9c2cc; font-size: 18px; line-height: 27px; }}
.action-button {{ background: #d49a5d; border: 3px solid #f4d2a6; border-radius: 15px; color: #111; }}
.dice-face {{ background: #30343a; border: 3px solid #9ca5ae; border-radius: 15px; }}
.dice-pip {{ background: #d8dde1; border-radius: 50%; }}
#new-phrase-label {{ color: #f1f3f4; text-align: center; padding: 0; font-size: 18px; line-height: 48px; letter-spacing: 0; white-space: nowrap; }}
</style>
</head>
<body><main id="presentation" aria-label="CP-004 150 pixel presentation">
{content}
</main></body>
</html>
'''


def center_text(draw: ImageDraw.ImageDraw, rect: tuple[int, int, int, int], text: str, font, fill, *, multiline=False):
    x, y, width, height = rect
    bbox = draw.multiline_textbbox((0, 0), text, font=font, spacing=0, align='center') if multiline else draw.textbbox((0, 0), text, font=font)
    text_width = bbox[2] - bbox[0]
    text_height = bbox[3] - bbox[1]
    draw.multiline_text((x + (width - text_width) / 2, y + (height - text_height) / 2 - bbox[1]), text,
                        font=font, fill=fill, spacing=0, align='center') if multiline else draw.text((x + (width - text_width) / 2, y + (height - text_height) / 2 - bbox[1]), text, font=font, fill=fill)


def render_png(items: list[dict]) -> None:
    image = Image.new('RGB', CANVAS, '#25272b')
    draw = ImageDraw.Draw(image)
    draw.rectangle((0, 0, CANVAS[0] - 1, CANVAS[1] - 1), outline='#08090a', width=3)
    label_font = load_font(21, bold=True)
    menu_font = load_font(20)
    dial_name_font = load_font(19)
    dial_value_font = load_font(18)
    action_font = load_font(18)
    for item in items:
        x, y, width, height = scaled(item['presentation_rect'])
        rect = (x, y, x + width - 1, y + height - 1)
        kind = item['maxclass']
        ident = item['id']
        text = label_value(item)
        if kind == 'comment':
            if ident == 'new-phrase-label':
                center_text(draw, (x, y, width, height), text, action_font, '#f1f3f4', multiline=True)
            else:
                font = load_font(round(float(item.get('fontsize', 7.0)) * SCALE), bold=True)
                if item.get('textjustification') == 1:
                    center_text(draw, (x, y, width, height), text, font, '#b8bec6')
                else:
                    draw.text((x + 6, y + 2), text, font=font, fill='#b8bec6')
        elif kind == 'live.menu':
            draw.rounded_rectangle(rect, radius=6, fill='#444951', outline='#69717b', width=3)
            center_text(draw, (x, y, width, height), text, menu_font, '#f5f6f7')
        elif kind == 'live.dial':
            draw.ellipse((x + 35, y + 5, x + 96, y + 66), fill='#515b66', outline='#7c8793', width=3)
            draw.line((x + width // 2, y + 13, x + width // 2, y + 38), fill='#d49a5d', width=5)
            center_text(draw, (x, y + 75, width, 27), parameter_shortname(item), dial_name_font, '#f5f6f7')
            center_text(draw, (x, y + 105, width, 27), text, dial_value_font, '#b9c2cc')
        elif kind == 'button':
            draw.rounded_rectangle(rect, radius=15, fill='#d49a5d', outline='#f4d2a6', width=3)
        elif kind == 'panel' and ident == 'dice-face':
            draw.rounded_rectangle(rect, radius=15, fill='#30343a', outline='#9ca5ae', width=3)
        elif kind == 'panel' and ident.startswith('dice-pip-'):
            draw.ellipse(rect, fill='#d8dde1')
    image.save(PNG_PATH, format='PNG', optimize=False)


def main() -> None:
    patch = json.loads(PATCH_PATH.read_text(encoding='utf-8'))['patcher']
    items = boxes(patch)
    HTML_PATH.parent.mkdir(parents=True, exist_ok=True)
    HTML_PATH.write_text(render_html(items), encoding='utf-8')
    render_png(items)
    print(json.dumps({'html': str(HTML_PATH), 'png': str(PNG_PATH), 'scale': SCALE, 'source': str(PATCH_PATH), 'presentation_boxes': len(items), 'canvas': list(CANVAS)}, indent=2))


if __name__ == '__main__':
    main()
