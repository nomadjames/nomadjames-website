#!/usr/bin/env node
'use strict';

const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const patcher = JSON.parse(fs.readFileSync(path.join(root, 'max/cymbal-phrase.maxpat'), 'utf8')).patcher;
const source = fs.readFileSync(path.join(root, 'max/cp_generator.js'), 'utf8');
const boxes = patcher.boxes.map((entry) => entry.box);
const byId = Object.fromEntries(boxes.map((box) => [box.id, box]));
const lines = patcher.lines.map((entry) => entry.patchline);
const parameters = ['motion', 'rate', 'density', 'air', 'accent', 'pocket', 'evolve', 'length'];

function fail(message) { throw new Error(message); }
function assert(condition, message) { if (!condition) fail(message); }
function connected(sourceId, sourceOutlet, destinationId, destinationInlet) {
  return lines.some((line) => line.source[0] === sourceId && line.source[1] === sourceOutlet && line.destination[0] === destinationId && line.destination[1] === destinationInlet);
}
function hasEmbeddedSource(box) {
  return box && box.text === 'v8' && box.textfile && box.textfile.embed === 1 && box.textfile.text === source;
}

assert(byId.in && byId.in.text === 'live.miditool.in', 'missing live.miditool.in');
assert(byId.out && byId.out.text === 'live.miditool.out', 'missing live.miditool.out');
assert(byId.generator && hasEmbeddedSource(byId.generator), 'generator source is not embedded or has drifted');
assert(patcher.devicewidth <= 150, 'device presentation exceeds the measured 150px MIDI Tool panel');
assert(patcher.openinpresentation === 1, 'patcher does not open in presentation mode');
assert(Array.isArray(patcher.dependency_cache) && patcher.dependency_cache.length === 0, 'external dependencies remain');
assert(!boxes.some((box) => /node\.script|anything/.test(String(box.text || ''))), 'forbidden external or legacy object remains');
for (const item of boxes.filter((box) => box.presentation === 1 && Array.isArray(box.presentation_rect))) {
  const [x, y, width, height] = item.presentation_rect;
  assert(x >= 0 && y >= 0 && x + width <= patcher.devicewidth, `${item.id} is clipped in presentation`);
  assert(height >= 0, `${item.id} has invalid presentation height`);
}
assert(byId.transaction.text === 't b l', 'transaction must be synchronous t b l');
assert(connected('in', 0, 'generator', 0), 'input is not connected to v8');
assert(connected('generator', 0, 'out', 0), 'v8 is not connected to output');
assert(connected('transaction', 1, 'generator', 1), 'settings are not applied before input transaction');
assert(connected('transaction', 0, 'in', 0), 'transaction does not bang live.miditool.in');
assert(connected('new-phrase-button', 0, 'new-phrase', 0), 'New Phrase action is not wired');
assert(connected('new-phrase', 0, 'transaction', 0), 'New Phrase action bypasses transaction');

assert(patcher.parameters && patcher.parameters.parameterbanks && patcher.parameters.parameterbanks['0'], 'missing parameter bank');
assert(JSON.stringify(patcher.parameters.parameterbanks['0'].parameters) === JSON.stringify(parameters), 'parameter bank is not exactly the requested eight controls');
const namedParameterKeys = Object.keys(patcher.parameters).filter((key) => key !== 'parameterbanks' && key !== 'inherited_shortname');
assert(JSON.stringify(namedParameterKeys) === JSON.stringify(parameters), 'patcher has a parameter outside the requested order');
for (const id of parameters) {
  const item = byId[id];
  assert(item && item.parameter_enable === 1 && item.presentation === 1, `${id} is not an automatable presentation control`);
  assert(Array.isArray(item.presentation_rect), `${id} has no presentation rectangle`);
  assert(patcher.parameters[id] && patcher.parameters[id][1] === id[0].toUpperCase() + id.slice(1), `${id} metadata missing short name`);
}
assert(byId.motion['saved_attribute_attributes'].valueof.parameter_enum.length === 4, 'Motion enum incomplete');
assert(byId.rate['saved_attribute_attributes'].valueof.parameter_enum.length === 4, 'Rate enum incomplete');
assert(byId.length['saved_attribute_attributes'].valueof.parameter_enum.length === 7, 'Length enum incomplete');
for (const handler of parameters.concat(['motion_index', 'rate_index', 'length_index', 'new_phrase', 'msg_dictionary'])) {
  assert(source.includes(`function ${handler}(`), `missing Max handler ${handler}`);
}
assert(source.includes('outlet_dictionary(0,'), 'wrapper does not use synchronous dictionary output');
assert(source.includes('function cpOutput()'), 'wrapper output function missing');
console.log(JSON.stringify({
  status: 'PASS',
  boxes: boxes.length,
  connections: lines.length,
  parameters,
  devicewidth: patcher.devicewidth,
  embedded_source_bytes: Buffer.byteLength(source),
  transaction: 'settings -> t b l -> live.miditool.in -> v8 -> live.miditool.out',
  self_contained: true,
}, null, 2));
