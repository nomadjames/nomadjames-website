#!/usr/bin/env python3
"""Build and round-trip validate the CP-004 AMXD container."""
from __future__ import annotations

import hashlib
import json
import struct
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PATCH = ROOT / 'max' / 'cymbal-phrase.maxpat'
SOURCE = ROOT / 'max' / 'cp_generator.js'
OUTPUT = ROOT / 'deliverables' / 'Cymbal-Phrase-CP-004.amxd'
HEADER = b'ampf\x04\x00\x00\x00nagg'
META = b'meta' + struct.pack('<I', 4) + b'\x00\x00\x00\x00'

def parse(data: bytes):
    if data[:12] != HEADER:
        raise ValueError('unexpected AMXD header')
    chunks = []
    position = 12
    while position < len(data):
        chunk_id = data[position:position + 4]
        size = struct.unpack_from('<I', data, position + 4)[0]
        end = position + 8 + size
        if end > len(data):
            raise ValueError('truncated AMXD chunk')
        chunks.append((chunk_id, data[position + 8:end]))
        position = end
    return chunks

source = SOURCE.read_text(encoding='utf-8')
document = json.loads(PATCH.read_text(encoding='utf-8'))
embedded = document['patcher']['boxes'][1]['box']['textfile']['text']
if embedded != source:
    raise ValueError('patcher embedded source differs from tested Max source')
payload = (json.dumps(document, ensure_ascii=False, indent='\t') + '\n').encode('utf-8') + b'\x00'
output = bytearray(HEADER + META)
output.extend(b'ptch')
output.extend(struct.pack('<I', len(payload)))
output.extend(payload)
OUTPUT.parent.mkdir(parents=True, exist_ok=True)
OUTPUT.write_bytes(output)
round_trip = parse(OUTPUT.read_bytes())
patch_chunks = [body for name, body in round_trip if name == b'ptch']
if len(patch_chunks) != 1 or json.loads(patch_chunks[0].rstrip(b'\x00').decode('utf-8')) != document:
    raise ValueError('AMXD patch chunk failed round-trip validation')
print(json.dumps({
    'output': str(OUTPUT),
    'bytes': OUTPUT.stat().st_size,
    'sha256': hashlib.sha256(OUTPUT.read_bytes()).hexdigest(),
    'chunks': [[name.decode('latin1'), len(body)] for name, body in round_trip],
    'embedded_source_bytes': len(source.encode('utf-8')),
    'round_trip': 'PASS',
}, indent=2))
