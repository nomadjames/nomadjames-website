#!/usr/bin/env python3
"""Build the compact CP-004 Max for Live MIDI Tool patcher."""
from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = (ROOT / 'max' / 'cp_generator.js').read_text(encoding='utf-8')

boxes = []
def box(identifier: str, maxclass: str, text: str | None = None, **values):
    item = {'id': identifier, 'maxclass': maxclass}
    if text is not None:
        item['text'] = text
    item.update(values)
    boxes.append({'box': item})
    return item

def comment(identifier: str, text: str, rect: list[float], visible: bool = True, **values):
    box(identifier, 'comment', text, patching_rect=[300.0, 40.0 + len(boxes) * 22.0, 100.0, 18.0], presentation=1 if visible else 0,
        presentation_rect=rect, **values)

def parameter(identifier: str, maxclass: str, short: str, long: str, rect: list[float], pre: str, *, enum=None, initial=0):
    value = {
        'parameter_initial': [initial],
        'parameter_initial_enable': 1,
        'parameter_longname': long,
        'parameter_mmax': float((len(enum) - 1) if enum else 100),
        'parameter_mmin': 0.0,
        'parameter_modmode': 3 if not enum else 0,
        'parameter_shortname': short,
        'parameter_type': 2 if enum else 0,
    }
    if enum:
        value['parameter_enum'] = enum
    if not enum:
        value['parameter_unitstyle'] = 5
    box(identifier, maxclass, numinlets=1, numoutlets=2, outlettype=['', 'float'], parameter_enable=1,
        patching_rect=[300.0, 70.0 + len(boxes) * 22.0, 80.0, 22.0], presentation=1,
        presentation_rect=rect, saved_attribute_attributes={'valueof': value}, varname='cp' + short)
    box(pre + '-pre', 'newobj', 'prepend ' + pre, patching_rect=[500.0, 70.0 + len(boxes) * 22.0, 120.0, 22.0])

box('in', 'newobj', 'live.miditool.in', patching_rect=[40.0, 430.0, 105.0, 22.0])
box('generator', 'newobj', 'v8', numinlets=2, numoutlets=1, outlettype=['dictionary'], patching_rect=[220.0, 430.0, 130.0, 22.0],
    saved_object_attributes={'parameter_enable': 0}, filename='none', textfile={'text': SOURCE, 'filename': 'none', 'flags': 0, 'embed': 1, 'autowatch': 1})
box('out', 'newobj', 'live.miditool.out', patching_rect=[420.0, 430.0, 112.0, 22.0])
box('transaction', 'newobj', 't b l', patching_rect=[220.0, 380.0, 55.0, 22.0])

# RD-011 presentation anchor: three 44px columns, 4px gaps, 150px total.
columns = [5.0, 53.0, 101.0]
for identifier, short, x, pre, enum, initial in [
    ('motion', 'Motion', columns[0], 'motion_index', ['Drive', 'Lift', 'Skip', 'Drift'], 0),
    ('rate', 'Rate', columns[1], 'rate_index', ['1/8', '1/16', '1/16T', '1/32'], 1),
    ('length', 'Length', columns[2], 'length_index', ['1 bar', '2 bars', '4 bars', '8 bars', '16 bars', '32 bars', '64 bars'], 3),
]:
    display = {'motion': 'MOVE', 'rate': 'RATE', 'length': 'LEN'}[identifier]
    comment(identifier + '-label', display, [x, 0.0, 44.0, 10.0], fontsize=8.0, textjustification=1)
    parameter(identifier, 'live.menu', short, 'Cymbal Phrase ' + short, [x, 10.0, 44.0, 16.0], pre, enum=enum, initial=initial)

for identifier, short, x, pre, initial in [
    ('density', 'Density', columns[0], 'density', 58),
    ('air', 'Air', columns[1], 'air', 32),
    ('accent', 'Accent', columns[2], 'accent', 64),
    ('pocket', 'Pocket', columns[0], 'pocket', 18),
    ('evolve', 'Evolve', columns[1], 'evolve', 24),
]:
    row_y = 31.0 if identifier in {'density', 'air', 'accent'} else 83.0
    parameter(identifier, 'live.dial', short, 'Cymbal Phrase ' + short, [x, row_y, 44.0, 50.0], pre, initial=initial)

# The button is the click target; the face and pips are visual overlays.
box('new-phrase', 'message', 'new_phrase', patching_rect=[40.0, 250.0, 100.0, 22.0])
box('new-phrase-button', 'button', patching_rect=[40.0, 250.0, 32.0, 32.0], presentation=1, presentation_rect=[110.0, 84.0, 26.0, 26.0])
box('dice-face', 'panel', patching_rect=[80.0, 250.0, 26.0, 26.0], presentation=1, ignoreclick=1, border=1,
    bgfillcolor=[0.18, 0.18, 0.18, 1.0], shape=0, presentation_rect=[110.0, 84.0, 26.0, 26.0], rounded=5,
    bordercolor=[0.62, 0.62, 0.62, 1.0])
for index, x, y in [
    (1, 115.0, 89.0), (2, 127.0, 89.0), (3, 121.0, 95.0),
    (4, 115.0, 101.0), (5, 127.0, 101.0),
]:
    box('dice-pip-' + str(index), 'panel', patching_rect=[80.0, 250.0, 4.0, 4.0], presentation=1, ignoreclick=1,
        border=0, bgfillcolor=[0.82, 0.82, 0.82, 1.0], shape=1, presentation_rect=[x, y, 4.0, 4.0])
comment('new-phrase-label', 'NEW', [101.0, 113.0, 44.0, 16.0], fontsize=8.0, ignoreclick=1)

lines = []
def connect(source: str, outlet: int, destination: str, inlet: int):
    lines.append({'patchline': {'source': [source, outlet], 'destination': [destination, inlet]}})

connect('in', 0, 'generator', 0)
connect('generator', 0, 'out', 0)
connect('transaction', 1, 'generator', 1)
connect('transaction', 0, 'in', 0)
for identifier, pre in [('motion', 'motion'), ('rate', 'rate'), ('length', 'length'), ('density', 'density'), ('air', 'air'), ('accent', 'accent'), ('pocket', 'pocket'), ('evolve', 'evolve')]:
    connect(identifier, 0, pre + '-pre', 0)
    connect(pre + '-pre', 0, 'transaction', 0)
connect('new-phrase-button', 0, 'new-phrase', 0)
connect('new-phrase', 0, 'transaction', 0)

parameter_map = {
    'motion': ['Cymbal Phrase Motion', 'Motion', 0],
    'rate': ['Cymbal Phrase Rate', 'Rate', 0],
    'density': ['Cymbal Phrase Density', 'Density', 0],
    'air': ['Cymbal Phrase Air', 'Air', 0],
    'accent': ['Cymbal Phrase Accent', 'Accent', 0],
    'pocket': ['Cymbal Phrase Pocket', 'Pocket', 0],
    'evolve': ['Cymbal Phrase Evolve', 'Evolve', 0],
    'length': ['Cymbal Phrase Length', 'Length', 0],
}
patcher = {
    'fileversion': 1,
    'appversion': {'major': 9, 'minor': 0, 'revision': 0, 'architecture': 'x64', 'modernui': 1},
    'classnamespace': 'box',
    'rect': [0.0, 0.0, 760.0, 500.0],
    'bglocked': 0,
    'openinpresentation': 1,
    'default_fontsize': 12.0,
    'default_fontface': 0,
    'default_fontname': 'Arial',
    'devicewidth': 150.0,
    'boxes': boxes,
    'lines': lines,
    'parameters': {
        **parameter_map,
        'parameterbanks': {'0': {'index': 0, 'name': '', 'parameters': ['motion', 'rate', 'density', 'air', 'accent', 'pocket', 'evolve', 'length']}},
        'inherited_shortname': 1,
    },
    'dependency_cache': [],
}
output = ROOT / 'max' / 'cymbal-phrase.maxpat'
output.write_text(json.dumps({'patcher': patcher}, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
print(json.dumps({'patch': str(output), 'boxes': len(boxes), 'connections': len(lines), 'parameters': list(parameter_map)}))
