'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const Phrase = require('../src/cymbal-phrase.js');

const LENGTHS = [1, 2, 4, 8, 16, 32, 64];
const PITCHES = new Set([42, 46, 48, 49, 50, 51]);
const FORBIDDEN_STOCK_TOM_PITCHES = new Set([44, 45, 47]);
const SAFE_FIELDS = ['pitch', 'start_time', 'duration', 'velocity', 'mute', 'probability', 'velocity_deviation', 'release_velocity'];

function prefix(result, beats) {
  return result.notes.filter((note) => note.start_time < beats).map((note) => [
    note.pitch, note.start_time, note.duration, note.velocity, note.mute,
  ]);
}

test('CP-004 exposes the observed Ableton stock-rack cymbal map and phrase ladder', () => {
  assert.deepEqual(Phrase.LENGTHS, LENGTHS);
  assert.deepEqual(Phrase.VOICES.map((voice) => [voice.name, voice.note, voice.pitch]), [
    ['Hat 1', 'F#1', 42], ['Hat 2', 'F#1', 42], ['Open Hat', 'A#1', 46],
    ['Crash 1', 'C#2', 49], ['Ride', 'D#2', 51], ['Ride Bell', 'D2', 50],
    ['Splash', 'C2', 48], ['Crash 2', 'C2', 48],
  ]);
});

test('stock-rack output never reaches observed tom lanes or stacks folded voices', () => {
  for (let seed = 0; seed < 64; seed += 1) {
    const result = Phrase.generate({ length: 6, seed: `stock-${seed}`, density: 100, air: 100, evolve: 100 });
    const keys = new Set();
    for (const note of result.notes) {
      assert.equal(FORBIDDEN_STOCK_TOM_PITCHES.has(note.pitch), false, `tom pitch ${note.pitch}`);
      const key = `${note.pitch}|${note.start_time}`;
      assert.equal(keys.has(key), false, `stacked mapped note ${key}`);
      keys.add(key);
    }
  }
});

test('each supported length is deterministic, bounded, and hierarchical', () => {
  for (let index = 0; index < LENGTHS.length; index += 1) {
    const settings = { length: index, seed: 'fixed', density: 62, air: 50, evolve: 100 };
    const first = Phrase.generate(settings);
    const second = Phrase.generate(settings);
    assert.deepEqual(first, second, `length ${LENGTHS[index]} is deterministic`);
    assert.equal(first.bars, LENGTHS[index]);
    assert.equal(first.rules.length, index + 1);
    assert.ok(first.notes.length > 0);
    for (const note of first.notes) {
      assert.ok(PITCHES.has(note.pitch), `unexpected pitch ${note.pitch}`);
      assert.ok(note.start_time >= 0 && note.start_time < first.totalBeats);
      assert.ok(note.duration > 0 && note.start_time + note.duration <= first.totalBeats);
      assert.ok(note.velocity >= 1 && note.velocity <= 127);
      for (const field of SAFE_FIELDS) assert.ok(Object.prototype.hasOwnProperty.call(note, field), `missing ${field}`);
      assert.equal(typeof note.mute, 'boolean');
      assert.ok(note.probability >= 0 && note.probability <= 1);
    }
  }
});

test('each longer phrase retains the exact shorter prefix under unchanged settings', () => {
  const settings = { seed: 'prefix', density: 70, air: 64, evolve: 100, rate: 1 };
  for (let index = 0; index < LENGTHS.length - 1; index += 1) {
    const short = Phrase.generate({ ...settings, length: index });
    const long = Phrase.generate({ ...settings, length: index + 1 });
    assert.deepEqual(prefix(long, short.totalBeats), prefix(short, short.totalBeats), `${short.bars}->${long.bars} prefix`);
  }
});

test('dimension independence keeps Accent on velocity and Pocket on timing', () => {
  const base = Phrase.generate({ length: 2, seed: 'independence', accent: 0, pocket: 0 });
  const accented = Phrase.generate({ length: 2, seed: 'independence', accent: 100, pocket: 0 });
  assert.deepEqual(base.notes.map((note) => [note.pitch, note.start_time]), accented.notes.map((note) => [note.pitch, note.start_time]));
  const pocketed = Phrase.generate({ length: 2, seed: 'independence', accent: 0, pocket: 100 });
  assert.deepEqual(
    base.notes.map((note) => note.pitch).sort((a, b) => a - b),
    pocketed.notes.map((note) => note.pitch).sort((a, b) => a - b),
  );
  assert.notDeepEqual(base.notes.map((note) => note.start_time), pocketed.notes.map((note) => note.start_time));
});

test('hierarchy adds answer, boundary, handoff, and macro voices without leaving the cymbal family', () => {
  const r8 = Phrase.generate({ length: 3, seed: 'hierarchy', evolve: 100, air: 100 });
  const r16 = Phrase.generate({ length: 4, seed: 'hierarchy', evolve: 100, air: 100 });
  const r64 = Phrase.generate({ length: 6, seed: 'hierarchy', evolve: 100, air: 100 });
  assert.ok(r8.notes.some((note) => note.voice === 'crash1' && note.role === 'boundary'));
  assert.ok(r16.notes.some((note) => note.voice === 'ride' && note.role === 'handoff'));
  for (const role of ['bell', 'splash', 'crash2']) assert.ok(r64.notes.some((note) => note.voice === role), role);
});

test('New Phrase advances the seed deterministically without adding a parameter', () => {
  assert.notEqual(Phrase.advanceSeed('17'), '17');
  assert.equal(Phrase.advanceSeed('17'), Phrase.advanceSeed('17'));
  assert.deepEqual(Object.keys(Phrase.defaults()).sort(), ['accent', 'air', 'density', 'evolve', 'length', 'motion', 'pocket', 'rate', 'seed'].sort());
});

console.log(JSON.stringify({ status: 'GREEN', lengths: LENGTHS, pitches: Array.from(PITCHES), safe_note_fields: SAFE_FIELDS }, null, 2));
