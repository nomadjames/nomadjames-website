'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const root = path.resolve(__dirname, '..');
const patch = JSON.parse(fs.readFileSync(path.join(root, 'max/cymbal-phrase.maxpat'), 'utf8')).patcher;
const items = Object.fromEntries(patch.boxes.map((entry) => [entry.box.id, entry.box]));

function rect(id) {
  assert.ok(Array.isArray(items[id]?.presentation_rect), `${id} has no presentation rectangle`);
  return items[id].presentation_rect;
}
function assertRect(id, expected) {
  assert.deepEqual(rect(id), expected, `${id} geometry`);
}


test('CP-003 uses native Live dial chrome in the RD-011 three-column presentation', () => {
  assert.equal(patch.devicewidth, 150);
  assertRect('motion', [5, 10, 44, 16]);
  assertRect('rate', [53, 10, 44, 16]);
  assertRect('length', [101, 10, 44, 16]);
  const dialRects = {
    density: [5, 31, 44, 50],
    air: [53, 31, 44, 50],
    accent: [101, 31, 44, 50],
    pocket: [5, 83, 44, 50],
    evolve: [53, 83, 44, 50],
  };
  for (const [id, expected] of Object.entries(dialRects)) assertRect(id, expected);
  assert.ok(rect('new-phrase-button')[0] >= 101, 'New must occupy the third column');
});

test('CP-003 does not duplicate Live dial labels and keeps action text short', () => {
  for (const id of ['motion-label', 'rate-label', 'length-label']) {
    const [x, y, width] = rect(id);
    assert.ok(x >= 0 && y >= 0 && x + width <= patch.devicewidth, `${id} is clipped`);
    assert.ok(width >= 40, `${id} is too narrow to remain legible`);
  }
  for (const id of ['density-label', 'air-label', 'accent-label', 'pocket-label', 'evolve-label']) {
    assert.equal(items[id], undefined, `${id} duplicates the label Live already draws for live.dial`);
  }
  assertRect('motion-label', [5, 0, 44, 10]);
  assertRect('rate-label', [53, 0, 44, 10]);
  assertRect('length-label', [101, 0, 44, 10]);
  assert.deepEqual(
    ['motion-label', 'rate-label', 'length-label'].map((id) => items[id].text),
    ['MOVE', 'RATE', 'LEN'],
  );
  for (const id of ['motion-label', 'rate-label', 'length-label']) {
    assert.equal(items[id].fontsize, 8);
    assert.equal(items[id].textjustification, 1);
  }
  assert.equal(items['new-phrase-label'].text, 'NEW');
  assert.equal(items['new-phrase-label'].ignoreclick, 1);
  assertRect('new-phrase-label', [101, 113, 44, 16]);
});

test('CP-003 keeps every presented box inside the 150 by 145 logical-pixel panel', () => {
  for (const item of Object.values(items).filter((box) => box.presentation === 1)) {
    const [x, y, width, height] = rect(item.id);
    assert.ok(x >= 0 && y >= 0, `${item.id} starts outside the presentation`);
    assert.ok(x + width <= 150, `${item.id} crosses the right edge`);
    assert.ok(y + height <= 145, `${item.id} crosses the bottom edge`);
  }
  for (const id of ['density', 'air', 'accent', 'pocket', 'evolve']) {
    assert.ok(rect(id)[2] >= 44, `${id} regressed to a squeezed dial`);
  }
});

test('New Phrase uses a separate third-column click target with nonblocking artwork', () => {
  assert.deepEqual(rect('new-phrase-button'), [110, 84, 26, 26]);
  assert.deepEqual(rect('dice-face'), rect('new-phrase-button'));
  assert.equal(items['dice-face'].ignoreclick, 1);
  for (let index = 1; index <= 5; index += 1) {
    assert.equal(items[`dice-pip-${index}`].ignoreclick, 1, `dice-pip-${index} blocks the button`);
  }
  assert.deepEqual(rect('new-phrase-label'), [101, 113, 44, 16]);
});
