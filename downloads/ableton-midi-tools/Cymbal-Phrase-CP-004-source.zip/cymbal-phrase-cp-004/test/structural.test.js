'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const root = path.resolve(__dirname, '..');
const source = fs.readFileSync(path.join(root, 'max/cp_generator.js'), 'utf8');
const patch = JSON.parse(fs.readFileSync(path.join(root, 'max/cymbal-phrase.maxpat'), 'utf8')).patcher;
const amxdPath = path.join(root, 'deliverables/Cymbal-Phrase-CP-004.amxd');
const parameterOrder = ['motion', 'rate', 'density', 'air', 'accent', 'pocket', 'evolve', 'length'];

function boxes(document) { return Object.fromEntries(document.boxes.map((entry) => [entry.box.id, entry.box])); }
function readChunks(buffer) {
  assert.equal(buffer.subarray(0, 4).toString('ascii'), 'ampf');
  assert.equal(buffer.subarray(8, 12).toString('ascii'), 'nagg');
  const chunks = [];
  let position = 12;
  while (position < buffer.length) {
    const id = buffer.subarray(position, position + 4).toString('ascii');
    const length = buffer.readUInt32LE(position + 4);
    chunks.push([id, buffer.subarray(position + 8, position + 8 + length)]);
    position += 8 + length;
  }
  return chunks;
}

test('patcher is compact, embedded, synchronous, and exactly eight-parameter', () => {
  const items = boxes(patch);
  assert.equal(patch.devicewidth, 150);
  assert.equal(patch.openinpresentation, 1);
  assert.equal(items.generator.text, 'v8');
  assert.equal(items.generator.textfile.embed, 1);
  assert.equal(items.generator.textfile.text, source);
  assert.deepEqual(patch.parameters.parameterbanks['0'].parameters, parameterOrder);
  assert.deepEqual(Object.keys(patch.parameters).filter((key) => !['parameterbanks', 'inherited_shortname'].includes(key)), parameterOrder);
  assert.equal(items.in.text, 'live.miditool.in');
  assert.equal(items.out.text, 'live.miditool.out');
  assert.equal(items.transaction.text, 't b l');
  for (const id of parameterOrder) {
    assert.equal(items[id].parameter_enable, 1);
    assert.equal(items[id].presentation, 1);
    const [x, , width] = items[id].presentation_rect;
    assert.ok(x >= 0 && x + width <= 150, `${id} is clipped`);
  }
});

test('AMXD embeds the exact tested patcher and V8 source bytes', () => {
  assert.ok(fs.existsSync(amxdPath), 'AMXD must be built before structural tests');
  const chunks = readChunks(fs.readFileSync(amxdPath));
  assert.deepEqual(chunks.map(([id]) => id), ['meta', 'ptch']);
  const embeddedPatch = JSON.parse(chunks[1][1].toString('utf8').replace(/\0$/, ''));
  const items = boxes(embeddedPatch.patcher);
  assert.equal(items.generator.textfile.text, source);
  assert.deepEqual(embeddedPatch.patcher.parameters.parameterbanks['0'].parameters, parameterOrder);
  assert.deepEqual(embeddedPatch.patcher, patch);
});

test('New Phrase action is wired through the transaction path', () => {
  const items = boxes(patch);
  const lines = patch.lines.map((entry) => entry.patchline);
  assert.equal(items['new-phrase-button'].maxclass, 'button');
  assert.deepEqual(lines.find((line) => line.source[0] === 'new-phrase-button'), {
    source: ['new-phrase-button', 0], destination: ['new-phrase', 0],
  });
  assert.deepEqual(lines.find((line) => line.source[0] === 'new-phrase'), {
    source: ['new-phrase', 0], destination: ['transaction', 0],
  });
  assert.match(source, /function new_phrase\(/);
});
