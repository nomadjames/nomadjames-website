'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

function loadWrapper() {
  const outputs = [];
  const context = {
    outlet_dictionary: (index, value) => outputs.push([index, value]),
    Math, JSON, Number, String, Object, Array, isFinite,
  };
  vm.createContext(context);
  vm.runInContext(fs.readFileSync(path.join(__dirname, '../max/cp_generator.js'), 'utf8'), context, { filename: 'cp_generator.js' });
  return { context, outputs };
}

function setting(wrapper, name, value) {
  assert.equal(typeof wrapper.context[name], 'function', `missing Max handler: ${name}`);
  wrapper.context[name](value);
}

test('Max 9 wrapper stores all eight controls before live.miditool.in transaction', () => {
  const wrapper = loadWrapper();
  setting(wrapper, 'motion_index', 2);
  setting(wrapper, 'rate_index', 3);
  setting(wrapper, 'density', 75);
  setting(wrapper, 'air', 45);
  setting(wrapper, 'accent', 80);
  setting(wrapper, 'pocket', 30);
  setting(wrapper, 'evolve', 65);
  setting(wrapper, 'length_index', 4);
  assert.deepEqual(JSON.parse(JSON.stringify(wrapper.context.cpSettings)), {
    motion: 2, rate: 3, density: 75, air: 45, accent: 80, pocket: 30, evolve: 65, length: 4, seed: '17',
  });
  assert.equal(wrapper.outputs.length, 0);
  wrapper.context.msg_dictionary({ notes: [] });
  assert.equal(wrapper.outputs.length, 1);
  assert.equal(wrapper.outputs[0][0], 0);
  assert.ok(Array.isArray(wrapper.outputs[0][1].notes));
});

test('named Max handlers emit through msg_dictionary and New Phrase advances the seed', () => {
  const wrapper = loadWrapper();
  wrapper.context.bang();
  assert.equal(wrapper.outputs.length, 1);
  const before = wrapper.outputs[0][1];
  const oldSeed = wrapper.context.cpSettings.seed;
  wrapper.context.new_phrase();
  assert.notEqual(wrapper.context.cpSettings.seed, oldSeed);
  assert.equal(wrapper.outputs.length, 1, 'New Phrase waits for the next MIDI Tool transaction');
  wrapper.context.msg_dictionary({ notes: [] });
  assert.equal(wrapper.outputs.length, 2);
  assert.notDeepEqual(wrapper.outputs[1][1].notes, before.notes);
});

test('wrapper emits only observed Ableton stock-rack cymbal lanes without mapped stacks', () => {
  const wrapper = loadWrapper();
  setting(wrapper, 'density', 100);
  setting(wrapper, 'air', 100);
  setting(wrapper, 'evolve', 100);
  setting(wrapper, 'length_index', 6);
  wrapper.context.msg_dictionary({ notes: [] });
  const notes = wrapper.outputs[0][1].notes;
  const allowed = new Set([42, 46, 48, 49, 50, 51]);
  const keys = new Set();
  for (const note of notes) {
    assert.ok(allowed.has(note.pitch), `wrapper emitted non-cymbal stock lane ${note.pitch}`);
    const key = `${note.pitch}|${note.start_time}`;
    assert.equal(keys.has(key), false, `wrapper emitted stacked mapped note ${key}`);
    keys.add(key);
  }
});

test('wrapper uses synchronous dictionary output without legacy dispatch or external JS', () => {
  const source = fs.readFileSync(path.join(__dirname, '../max/cp_generator.js'), 'utf8');
  assert.match(source, /function msg_dictionary\(/);
  assert.match(source, /outlet_dictionary\(0,/);
  assert.doesNotMatch(source, /function anything\(/);
  assert.doesNotMatch(source, /new Dict\(/);
  assert.doesNotMatch(source, /node\.script/);
});

console.log(JSON.stringify({ status: 'PASS', wrapper: 'Max 9 v8', transaction: 'msg_dictionary -> outlet_dictionary', handlers: 8 }, null, 2));
