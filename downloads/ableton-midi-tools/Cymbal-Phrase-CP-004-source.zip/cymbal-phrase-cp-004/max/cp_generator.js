/*
 * Cymbal Phrase CP-001 portable engine for Ableton Live 12 MIDI Tools.
 * Dependency-free and ES5-compatible for Node and Max 9 V8.
 */
(function (root, factory) {
  if (typeof module !== 'undefined' && module.exports) module.exports = factory();
  else root.CymbalPhrase = factory();
}(this, function () {
  'use strict';

  var LENGTHS = [1, 2, 4, 8, 16, 32, 64];
  var MOTIONS = ['Drive', 'Lift', 'Skip', 'Drift'];
  var RATES = ['1/8', '1/16', '1/16T', '1/32'];
  var RATE_SLOTS = [8, 16, 24, 32];
  var VOICES = [
    { id: 'hat1', name: 'Hat 1', detail: 'Closed', note: 'F#1', pitch: 42 },
    { id: 'hat2', name: 'Hat 2', detail: 'Closed alternate', note: 'F#1', pitch: 42 },
    { id: 'open', name: 'Open Hat', detail: 'Open', note: 'A#1', pitch: 46 },
    { id: 'crash1', name: 'Crash 1', detail: 'Boundary', note: 'C#2', pitch: 49 },
    { id: 'ride', name: 'Ride', detail: 'Alt clock', note: 'D#2', pitch: 51 },
    { id: 'bell', name: 'Ride Bell', detail: 'Marker', note: 'D2', pitch: 50 },
    { id: 'splash', name: 'Splash', detail: 'Lift', note: 'C2', pitch: 48 },
    { id: 'crash2', name: 'Crash 2', detail: 'Final boundary', note: 'C2', pitch: 48 }
  ];
  var RULES = [
    { bars: 1, short: 'Core', name: 'Core groove', detail: 'Stable clock, accents and gaps establish identity.' },
    { bars: 2, short: 'Answer', name: 'Answer bar', detail: 'Bar two answers with one bounded omission or accent turn.' },
    { bars: 4, short: 'Resolve', name: 'Phrase resolution', detail: 'Open-hat lift resolves back to a closed or pedal state.' },
    { bars: 8, short: 'Boundary', name: 'Section boundary', detail: 'A guarded crash marks the eight-bar edge.' },
    { bars: 16, short: 'Handoff', name: 'Clock handoff', detail: 'Ride can briefly take the clock while hats thin out.' },
    { bars: 32, short: 'Contour', name: 'Energy contour', detail: 'The second phrase half adds a bounded contour.' },
    { bars: 64, short: 'Arc', name: 'Macro arc', detail: 'Bell, splash and Crash 2 become structural markers.' }
  ];

  function clamp(value, low, high) {
    var number = Number(value);
    if (!(number === number) || !isFinite(number)) number = low;
    return Math.max(low, Math.min(high, number));
  }
  function integer(value, fallback) {
    var number = Number(value);
    if (!(number === number) || !isFinite(number)) return fallback;
    return Math.round(number);
  }
  function imul(a, b) {
    if (Math.imul) return Math.imul(a, b);
    var ah = (a >>> 16) & 65535;
    var al = a & 65535;
    return (al * b + (((ah * b) & 65535) << 16)) | 0;
  }
  function hashSeed(value) {
    var text = String(value), hash = 2166136261, index;
    for (index = 0; index < text.length; index += 1) {
      hash ^= text.charCodeAt(index);
      hash = imul(hash, 16777619);
    }
    return hash >>> 0;
  }
  function random(seed, key) {
    return hashSeed(String(seed) + '|' + String(key)) / 4294967296;
  }
  function round(value) { return Math.round(value * 1000000) / 1000000; }
  function voice(id) {
    var index;
    for (index = 0; index < VOICES.length; index += 1) if (VOICES[index].id === id) return VOICES[index];
    return VOICES[0];
  }
  function defaults() {
    return { motion: 0, rate: 1, density: 58, air: 32, accent: 64, pocket: 18, evolve: 24, length: 3, seed: '17' };
  }
  function normalizeSettings(input) {
    var source = input || {}, result = defaults(), key;
    for (key in result) if (Object.prototype.hasOwnProperty.call(source, key)) result[key] = source[key];
    result.motion = integer(clamp(result.motion, 0, MOTIONS.length - 1), 0);
    result.rate = integer(clamp(result.rate, 0, RATES.length - 1), 1);
    result.length = integer(clamp(result.length, 0, LENGTHS.length - 1), 3);
    ['density', 'air', 'accent', 'pocket', 'evolve'].forEach(function (name) {
      result[name] = clamp(result[name], 0, 100);
    });
    result.seed = String(result.seed);
    return result;
  }
  function slotsForRate(rate) { return RATE_SLOTS[integer(clamp(rate, 0, 3), 1)]; }
  function candidate(motion, slot, slots, bar) {
    var eighth = Math.max(1, Math.round(slots / 8));
    if (motion === 0) return true;
    if (motion === 1) return slot % eighth === 0 || slot % Math.max(1, Math.round(slots / 4)) === 0;
    if (motion === 2) return ((slot * 5 + bar * 3) % 11) < 6;
    return ((slot + bar) % 15) % 3 !== 2;
  }
  function add(events, id, bar, slot, slots, velocity, offset, role) {
    var selected = voice(id), start = bar * 4 + slot / slots * 4 + offset;
    events.push({
      voice: selected.id,
      name: selected.name,
      note: selected.note,
      pitch: selected.pitch,
      bar: bar + 1,
      slot: slot,
      start_time: round(clamp(start, 0, 256)),
      duration: id === 'open' ? 0.42 : 0.12,
      velocity: integer(clamp(velocity, 1, 127), 1),
      mute: false,
      probability: 1,
      velocity_deviation: 0,
      release_velocity: 64,
      offset: round(offset),
      role: role || selected.detail
    });
  }
  function addClockBar(events, settings, bar, slots, bars) {
    var density = settings.density, accent = settings.accent, air = settings.air;
    var quarter = Math.max(1, Math.round(slots / 4)), eighth = Math.max(1, Math.round(slots / 8));
    var slot, strong, keep, id, baseVelocity, timing;
    for (slot = 0; slot < slots; slot += 1) {
      if (!candidate(settings.motion, slot, slots, bar)) continue;
      strong = slot % quarter === 0;
      keep = strong || random(settings.seed, 'position:' + bar + ':' + slot) * 100 < density;
      if (!keep) continue;
      id = 'hat1';
      if (slot % eighth === 0 && random(settings.seed, 'pedal:' + bar + ':' + slot) * 100 < air * 0.42) id = 'hat2';
      if (!strong && random(settings.seed, 'open:' + bar + ':' + slot) * 100 < air * 0.18) id = 'open';
      if (bar >= 12 && bar % 16 >= 12 && random(settings.seed, 'ride:' + bar + ':' + slot) * 100 < settings.evolve * 0.75) id = 'ride';
      baseVelocity = strong ? 92 : (slot % eighth === 0 ? 78 : 64);
      baseVelocity += (random(settings.seed, 'velocity:' + bar + ':' + slot) - 0.5) * 8;
      baseVelocity += (strong ? 12 : 0) * settings.accent / 100;
      timing = 0;
      if (!strong) timing = (random(settings.seed, 'pocket:' + bar + ':' + slot) - 0.5) * 0.08 * settings.pocket / 100;
      add(events, id, bar, slot, slots, baseVelocity, timing, 'clock');
    }
    /* Each structural addition starts on its own bar, so shorter prefixes remain identical. */
    if (bar % 2 === 1 && settings.evolve > 0 && random(settings.seed, 'answer:' + bar) * 100 < settings.evolve) {
      add(events, 'hat2', bar, Math.max(0, slots - 2), slots, 58 + settings.accent * 0.2, 0, 'answer');
    }
    if (bar % 4 === 3 && settings.air > 8) {
      add(events, 'open', bar, Math.max(0, slots - 2), slots, 76 + settings.air * 0.28, 0, 'resolution');
    }
    if (bar >= 7 && bar % 8 === 7 && settings.evolve > 8) {
      add(events, 'crash1', bar, 0, slots, 88 + settings.accent * 0.25, 0, 'boundary');
    }
    if (bar >= 12 && bar % 16 === 12 && settings.evolve > 16) {
      add(events, 'ride', bar, 0, slots, 84 + settings.accent * 0.2, 0, 'handoff');
    }
    if (bar >= 32 && bar % 32 === 0 && settings.evolve > 24) {
      add(events, 'bell', bar, 0, slots, 90, 0, 'contour marker');
    }
    if (bar >= 48 && bar % 64 === 48 && settings.air > 8) {
      add(events, 'splash', bar, Math.round(slots / 2), slots, 92, 0, 'macro lift');
    }
    if (bar === bars - 1 && bars >= 64) {
      add(events, 'crash2', bar, slots - 1, slots, 112, 0, 'final boundary');
    }
  }
  function toLiveNotes(events, totalBeats) {
    var merged = {}, order = [];
    events.forEach(function (item) {
      var maxStart = Math.max(0, totalBeats - item.duration);
      var note = {}, existing, duration;
      var key;
      for (key in item) if (Object.prototype.hasOwnProperty.call(item, key)) note[key] = item[key];
      note.start_time = round(clamp(item.start_time, 0, maxStart));
      key = String(note.pitch) + '|' + String(note.start_time);
      if (!Object.prototype.hasOwnProperty.call(merged, key)) {
        merged[key] = note;
        order.push(key);
        return;
      }
      existing = merged[key];
      duration = Math.max(existing.duration, note.duration);
      if (note.velocity > existing.velocity) {
        note.duration = duration;
        merged[key] = note;
      } else {
        existing.duration = duration;
      }
    });
    return order.map(function (key) { return merged[key]; });
  }
  function generate(input) {
    var settings = normalizeSettings(input), bars = LENGTHS[settings.length], slots = slotsForRate(settings.rate);
    var events = [], bar, totalBeats = bars * 4;
    for (bar = 0; bar < bars; bar += 1) addClockBar(events, settings, bar, slots, bars);
    events.sort(function (a, b) { return a.start_time - b.start_time || a.pitch - b.pitch || a.velocity - b.velocity; });
    return {
      notes: toLiveNotes(events, totalBeats),
      settings: settings,
      bars: bars,
      totalBeats: totalBeats,
      motion: MOTIONS[settings.motion],
      rate: RATES[settings.rate],
      rules: RULES.filter(function (rule) { return rule.bars <= bars; }),
      voices: VOICES
    };
  }
  function advanceSeed(seed) { return hashSeed(String(seed) + '|new-phrase').toString(36); }
  return {
    LENGTHS: LENGTHS,
    MOTIONS: MOTIONS,
    RATES: RATES,
    VOICES: VOICES,
    RULES: RULES,
    defaults: defaults,
    normalizeSettings: normalizeSettings,
    slotsForRate: slotsForRate,
    generate: generate,
    generatePattern: generate,
    advanceSeed: advanceSeed
  };
}));

/* Max 9 V8 wrapper: all settings are stored before the transaction bangs. */
autowatch = 1;
inlets = 2;
outlets = 1;

var cpSettings = {
  motion: 0,
  rate: 1,
  density: 58,
  air: 32,
  accent: 64,
  pocket: 18,
  evolve: 24,
  length: 3,
  seed: '17'
};
var cpCore = (typeof CymbalPhrase !== 'undefined') ? CymbalPhrase : ((typeof module !== 'undefined') ? module.exports : null);

function cpOutput() {
  outlet_dictionary(0, cpCore.generate(cpSettings));
}

/* live.miditool.in arrives here as a native dictionary. */
function msg_dictionary(value) { cpOutput(); }
function bang() { cpOutput(); }

function motion(value) { if (value !== undefined) cpSettings.motion = value; }
function motion_index(value) { cpSettings.motion = Math.max(0, Math.min(3, Math.round(Number(value) || 0))); }
function rate(value) { if (value !== undefined) cpSettings.rate = value; }
function rate_index(value) { cpSettings.rate = Math.max(0, Math.min(3, Math.round(Number(value) || 0))); }
function density(value) { if (value !== undefined) cpSettings.density = value; }
function air(value) { if (value !== undefined) cpSettings.air = value; }
function accent(value) { if (value !== undefined) cpSettings.accent = value; }
function pocket(value) { if (value !== undefined) cpSettings.pocket = value; }
function evolve(value) { if (value !== undefined) cpSettings.evolve = value; }
function length(value) { if (value !== undefined) cpSettings.length = value; }
function length_index(value) { cpSettings.length = Math.max(0, Math.min(6, Math.round(Number(value) || 0))); }
function new_phrase() { cpSettings.seed = cpCore.advanceSeed(cpSettings.seed); }
