{
  "patcher": {
    "fileversion": 1,
    "appversion": {
      "major": 9,
      "minor": 0,
      "revision": 0,
      "architecture": "x64",
      "modernui": 1
    },
    "classnamespace": "box",
    "rect": [
      0.0,
      0.0,
      760.0,
      500.0
    ],
    "bglocked": 0,
    "openinpresentation": 1,
    "default_fontsize": 12.0,
    "default_fontface": 0,
    "default_fontname": "Arial",
    "devicewidth": 150.0,
    "boxes": [
      {
        "box": {
          "id": "in",
          "maxclass": "newobj",
          "text": "live.miditool.in",
          "patching_rect": [
            40.0,
            430.0,
            105.0,
            22.0
          ]
        }
      },
      {
        "box": {
          "id": "generator",
          "maxclass": "newobj",
          "text": "v8",
          "numinlets": 2,
          "numoutlets": 1,
          "outlettype": [
            "dictionary"
          ],
          "patching_rect": [
            220.0,
            430.0,
            130.0,
            22.0
          ],
          "saved_object_attributes": {
            "parameter_enable": 0
          },
          "filename": "none",
          "textfile": {
            "text": "/*\n * Cymbal Phrase CP-001 portable engine for Ableton Live 12 MIDI Tools.\n * Dependency-free and ES5-compatible for Node and Max 9 V8.\n */\n(function (root, factory) {\n  if (typeof module !== 'undefined' && module.exports) module.exports = factory();\n  else root.CymbalPhrase = factory();\n}(this, function () {\n  'use strict';\n\n  var LENGTHS = [1, 2, 4, 8, 16, 32, 64];\n  var MOTIONS = ['Drive', 'Lift', 'Skip', 'Drift'];\n  var RATES = ['1/8', '1/16', '1/16T', '1/32'];\n  var RATE_SLOTS = [8, 16, 24, 32];\n  var VOICES = [\n    { id: 'hat1', name: 'Hat 1', detail: 'Closed', note: 'F#1', pitch: 42 },\n    { id: 'hat2', name: 'Hat 2', detail: 'Closed alternate', note: 'F#1', pitch: 42 },\n    { id: 'open', name: 'Open Hat', detail: 'Open', note: 'A#1', pitch: 46 },\n    { id: 'crash1', name: 'Crash 1', detail: 'Boundary', note: 'C#2', pitch: 49 },\n    { id: 'ride', name: 'Ride', detail: 'Alt clock', note: 'D#2', pitch: 51 },\n    { id: 'bell', name: 'Ride Bell', detail: 'Marker', note: 'D2', pitch: 50 },\n    { id: 'splash', name: 'Splash', detail: 'Lift', note: 'C2', pitch: 48 },\n    { id: 'crash2', name: 'Crash 2', detail: 'Final boundary', note: 'C2', pitch: 48 }\n  ];\n  var RULES = [\n    { bars: 1, short: 'Core', name: 'Core groove', detail: 'Stable clock, accents and gaps establish identity.' },\n    { bars: 2, short: 'Answer', name: 'Answer bar', detail: 'Bar two answers with one bounded omission or accent turn.' },\n    { bars: 4, short: 'Resolve', name: 'Phrase resolution', detail: 'Open-hat lift resolves back to a closed or pedal state.' },\n    { bars: 8, short: 'Boundary', name: 'Section boundary', detail: 'A guarded crash marks the eight-bar edge.' },\n    { bars: 16, short: 'Handoff', name: 'Clock handoff', detail: 'Ride can briefly take the clock while hats thin out.' },\n    { bars: 32, short: 'Contour', name: 'Energy contour', detail: 'The second phrase half adds a bounded contour.' },\n    { bars: 64, short: 'Arc', name: 'Macro arc', detail: 'Bell, splash and Crash 2 become structural markers.' }\n  ];\n\n  function clamp(value, low, high) {\n    var number = Number(value);\n    if (!(number === number) || !isFinite(number)) number = low;\n    return Math.max(low, Math.min(high, number));\n  }\n  function integer(value, fallback) {\n    var number = Number(value);\n    if (!(number === number) || !isFinite(number)) return fallback;\n    return Math.round(number);\n  }\n  function imul(a, b) {\n    if (Math.imul) return Math.imul(a, b);\n    var ah = (a >>> 16) & 65535;\n    var al = a & 65535;\n    return (al * b + (((ah * b) & 65535) << 16)) | 0;\n  }\n  function hashSeed(value) {\n    var text = String(value), hash = 2166136261, index;\n    for (index = 0; index < text.length; index += 1) {\n      hash ^= text.charCodeAt(index);\n      hash = imul(hash, 16777619);\n    }\n    return hash >>> 0;\n  }\n  function random(seed, key) {\n    return hashSeed(String(seed) + '|' + String(key)) / 4294967296;\n  }\n  function round(value) { return Math.round(value * 1000000) / 1000000; }\n  function voice(id) {\n    var index;\n    for (index = 0; index < VOICES.length; index += 1) if (VOICES[index].id === id) return VOICES[index];\n    return VOICES[0];\n  }\n  function defaults() {\n    return { motion: 0, rate: 1, density: 58, air: 32, accent: 64, pocket: 18, evolve: 24, length: 3, seed: '17' };\n  }\n  function normalizeSettings(input) {\n    var source = input || {}, result = defaults(), key;\n    for (key in result) if (Object.prototype.hasOwnProperty.call(source, key)) result[key] = source[key];\n    result.motion = integer(clamp(result.motion, 0, MOTIONS.length - 1), 0);\n    result.rate = integer(clamp(result.rate, 0, RATES.length - 1), 1);\n    result.length = integer(clamp(result.length, 0, LENGTHS.length - 1), 3);\n    ['density', 'air', 'accent', 'pocket', 'evolve'].forEach(function (name) {\n      result[name] = clamp(result[name], 0, 100);\n    });\n    result.seed = String(result.seed);\n    return result;\n  }\n  function slotsForRate(rate) { return RATE_SLOTS[integer(clamp(rate, 0, 3), 1)]; }\n  function candidate(motion, slot, slots, bar) {\n    var eighth = Math.max(1, Math.round(slots / 8));\n    if (motion === 0) return true;\n    if (motion === 1) return slot % eighth === 0 || slot % Math.max(1, Math.round(slots / 4)) === 0;\n    if (motion === 2) return ((slot * 5 + bar * 3) % 11) < 6;\n    return ((slot + bar) % 15) % 3 !== 2;\n  }\n  function add(events, id, bar, slot, slots, velocity, offset, role) {\n    var selected = voice(id), start = bar * 4 + slot / slots * 4 + offset;\n    events.push({\n      voice: selected.id,\n      name: selected.name,\n      note: selected.note,\n      pitch: selected.pitch,\n      bar: bar + 1,\n      slot: slot,\n      start_time: round(clamp(start, 0, 256)),\n      duration: id === 'open' ? 0.42 : 0.12,\n      velocity: integer(clamp(velocity, 1, 127), 1),\n      mute: false,\n      probability: 1,\n      velocity_deviation: 0,\n      release_velocity: 64,\n      offset: round(offset),\n      role: role || selected.detail\n    });\n  }\n  function addClockBar(events, settings, bar, slots, bars) {\n    var density = settings.density, accent = settings.accent, air = settings.air;\n    var quarter = Math.max(1, Math.round(slots / 4)), eighth = Math.max(1, Math.round(slots / 8));\n    var slot, strong, keep, id, baseVelocity, timing;\n    for (slot = 0; slot < slots; slot += 1) {\n      if (!candidate(settings.motion, slot, slots, bar)) continue;\n      strong = slot % quarter === 0;\n      keep = strong || random(settings.seed, 'position:' + bar + ':' + slot) * 100 < density;\n      if (!keep) continue;\n      id = 'hat1';\n      if (slot % eighth === 0 && random(settings.seed, 'pedal:' + bar + ':' + slot) * 100 < air * 0.42) id = 'hat2';\n      if (!strong && random(settings.seed, 'open:' + bar + ':' + slot) * 100 < air * 0.18) id = 'open';\n      if (bar >= 12 && bar % 16 >= 12 && random(settings.seed, 'ride:' + bar + ':' + slot) * 100 < settings.evolve * 0.75) id = 'ride';\n      baseVelocity = strong ? 92 : (slot % eighth === 0 ? 78 : 64);\n      baseVelocity += (random(settings.seed, 'velocity:' + bar + ':' + slot) - 0.5) * 8;\n      baseVelocity += (strong ? 12 : 0) * settings.accent / 100;\n      timing = 0;\n      if (!strong) timing = (random(settings.seed, 'pocket:' + bar + ':' + slot) - 0.5) * 0.08 * settings.pocket / 100;\n      add(events, id, bar, slot, slots, baseVelocity, timing, 'clock');\n    }\n    /* Each structural addition starts on its own bar, so shorter prefixes remain identical. */\n    if (bar % 2 === 1 && settings.evolve > 0 && random(settings.seed, 'answer:' + bar) * 100 < settings.evolve) {\n      add(events, 'hat2', bar, Math.max(0, slots - 2), slots, 58 + settings.accent * 0.2, 0, 'answer');\n    }\n    if (bar % 4 === 3 && settings.air > 8) {\n      add(events, 'open', bar, Math.max(0, slots - 2), slots, 76 + settings.air * 0.28, 0, 'resolution');\n    }\n    if (bar >= 7 && bar % 8 === 7 && settings.evolve > 8) {\n      add(events, 'crash1', bar, 0, slots, 88 + settings.accent * 0.25, 0, 'boundary');\n    }\n    if (bar >= 12 && bar % 16 === 12 && settings.evolve > 16) {\n      add(events, 'ride', bar, 0, slots, 84 + settings.accent * 0.2, 0, 'handoff');\n    }\n    if (bar >= 32 && bar % 32 === 0 && settings.evolve > 24) {\n      add(events, 'bell', bar, 0, slots, 90, 0, 'contour marker');\n    }\n    if (bar >= 48 && bar % 64 === 48 && settings.air > 8) {\n      add(events, 'splash', bar, Math.round(slots / 2), slots, 92, 0, 'macro lift');\n    }\n    if (bar === bars - 1 && bars >= 64) {\n      add(events, 'crash2', bar, slots - 1, slots, 112, 0, 'final boundary');\n    }\n  }\n  function toLiveNotes(events, totalBeats) {\n    var merged = {}, order = [];\n    events.forEach(function (item) {\n      var maxStart = Math.max(0, totalBeats - item.duration);\n      var note = {}, existing, duration;\n      var key;\n      for (key in item) if (Object.prototype.hasOwnProperty.call(item, key)) note[key] = item[key];\n      note.start_time = round(clamp(item.start_time, 0, maxStart));\n      key = String(note.pitch) + '|' + String(note.start_time);\n      if (!Object.prototype.hasOwnProperty.call(merged, key)) {\n        merged[key] = note;\n        order.push(key);\n        return;\n      }\n      existing = merged[key];\n      duration = Math.max(existing.duration, note.duration);\n      if (note.velocity > existing.velocity) {\n        note.duration = duration;\n        merged[key] = note;\n      } else {\n        existing.duration = duration;\n      }\n    });\n    return order.map(function (key) { return merged[key]; });\n  }\n  function generate(input) {\n    var settings = normalizeSettings(input), bars = LENGTHS[settings.length], slots = slotsForRate(settings.rate);\n    var events = [], bar, totalBeats = bars * 4;\n    for (bar = 0; bar < bars; bar += 1) addClockBar(events, settings, bar, slots, bars);\n    events.sort(function (a, b) { return a.start_time - b.start_time || a.pitch - b.pitch || a.velocity - b.velocity; });\n    return {\n      notes: toLiveNotes(events, totalBeats),\n      settings: settings,\n      bars: bars,\n      totalBeats: totalBeats,\n      motion: MOTIONS[settings.motion],\n      rate: RATES[settings.rate],\n      rules: RULES.filter(function (rule) { return rule.bars <= bars; }),\n      voices: VOICES\n    };\n  }\n  function advanceSeed(seed) { return hashSeed(String(seed) + '|new-phrase').toString(36); }\n  return {\n    LENGTHS: LENGTHS,\n    MOTIONS: MOTIONS,\n    RATES: RATES,\n    VOICES: VOICES,\n    RULES: RULES,\n    defaults: defaults,\n    normalizeSettings: normalizeSettings,\n    slotsForRate: slotsForRate,\n    generate: generate,\n    generatePattern: generate,\n    advanceSeed: advanceSeed\n  };\n}));\n\n/* Max 9 V8 wrapper: all settings are stored before the transaction bangs. */\nautowatch = 1;\ninlets = 2;\noutlets = 1;\n\nvar cpSettings = {\n  motion: 0,\n  rate: 1,\n  density: 58,\n  air: 32,\n  accent: 64,\n  pocket: 18,\n  evolve: 24,\n  length: 3,\n  seed: '17'\n};\nvar cpCore = (typeof CymbalPhrase !== 'undefined') ? CymbalPhrase : ((typeof module !== 'undefined') ? module.exports : null);\n\nfunction cpOutput() {\n  outlet_dictionary(0, cpCore.generate(cpSettings));\n}\n\n/* live.miditool.in arrives here as a native dictionary. */\nfunction msg_dictionary(value) { cpOutput(); }\nfunction bang() { cpOutput(); }\n\nfunction motion(value) { if (value !== undefined) cpSettings.motion = value; }\nfunction motion_index(value) { cpSettings.motion = Math.max(0, Math.min(3, Math.round(Number(value) || 0))); }\nfunction rate(value) { if (value !== undefined) cpSettings.rate = value; }\nfunction rate_index(value) { cpSettings.rate = Math.max(0, Math.min(3, Math.round(Number(value) || 0))); }\nfunction density(value) { if (value !== undefined) cpSettings.density = value; }\nfunction air(value) { if (value !== undefined) cpSettings.air = value; }\nfunction accent(value) { if (value !== undefined) cpSettings.accent = value; }\nfunction pocket(value) { if (value !== undefined) cpSettings.pocket = value; }\nfunction evolve(value) { if (value !== undefined) cpSettings.evolve = value; }\nfunction length(value) { if (value !== undefined) cpSettings.length = value; }\nfunction length_index(value) { cpSettings.length = Math.max(0, Math.min(6, Math.round(Number(value) || 0))); }\nfunction new_phrase() { cpSettings.seed = cpCore.advanceSeed(cpSettings.seed); }\n",
            "filename": "none",
            "flags": 0,
            "embed": 1,
            "autowatch": 1
          }
        }
      },
      {
        "box": {
          "id": "out",
          "maxclass": "newobj",
          "text": "live.miditool.out",
          "patching_rect": [
            420.0,
            430.0,
            112.0,
            22.0
          ]
        }
      },
      {
        "box": {
          "id": "transaction",
          "maxclass": "newobj",
          "text": "t b l",
          "patching_rect": [
            220.0,
            380.0,
            55.0,
            22.0
          ]
        }
      },
      {
        "box": {
          "id": "motion-label",
          "maxclass": "comment",
          "text": "MOVE",
          "patching_rect": [
            300.0,
            128.0,
            100.0,
            18.0
          ],
          "presentation": 1,
          "presentation_rect": [
            5.0,
            0.0,
            44.0,
            10.0
          ],
          "fontsize": 8.0,
          "textjustification": 1
        }
      },
      {
        "box": {
          "id": "motion",
          "maxclass": "live.menu",
          "numinlets": 1,
          "numoutlets": 2,
          "outlettype": [
            "",
            "float"
          ],
          "parameter_enable": 1,
          "patching_rect": [
            300.0,
            180.0,
            80.0,
            22.0
          ],
          "presentation": 1,
          "presentation_rect": [
            5.0,
            10.0,
            44.0,
            16.0
          ],
          "saved_attribute_attributes": {
            "valueof": {
              "parameter_initial": [
                0
              ],
              "parameter_initial_enable": 1,
              "parameter_longname": "Cymbal Phrase Motion",
              "parameter_mmax": 3.0,
              "parameter_mmin": 0.0,
              "parameter_modmode": 0,
              "parameter_shortname": "Motion",
              "parameter_type": 2,
              "parameter_enum": [
                "Drive",
                "Lift",
                "Skip",
                "Drift"
              ]
            }
          },
          "varname": "cpMotion"
        }
      },
      {
        "box": {
          "id": "motion_index-pre",
          "maxclass": "newobj",
          "text": "prepend motion_index",
          "patching_rect": [
            500.0,
            202.0,
            120.0,
            22.0
          ]
        }
      },
      {
        "box": {
          "id": "rate-label",
          "maxclass": "comment",
          "text": "RATE",
          "patching_rect": [
            300.0,
            194.0,
            100.0,
            18.0
          ],
          "presentation": 1,
          "presentation_rect": [
            53.0,
            0.0,
            44.0,
            10.0
          ],
          "fontsize": 8.0,
          "textjustification": 1
        }
      },
      {
        "box": {
          "id": "rate",
          "maxclass": "live.menu",
          "numinlets": 1,
          "numoutlets": 2,
          "outlettype": [
            "",
            "float"
          ],
          "parameter_enable": 1,
          "patching_rect": [
            300.0,
            246.0,
            80.0,
            22.0
          ],
          "presentation": 1,
          "presentation_rect": [
            53.0,
            10.0,
            44.0,
            16.0
          ],
          "saved_attribute_attributes": {
            "valueof": {
              "parameter_initial": [
                1
              ],
              "parameter_initial_enable": 1,
              "parameter_longname": "Cymbal Phrase Rate",
              "parameter_mmax": 3.0,
              "parameter_mmin": 0.0,
              "parameter_modmode": 0,
              "parameter_shortname": "Rate",
              "parameter_type": 2,
              "parameter_enum": [
                "1/8",
                "1/16",
                "1/16T",
                "1/32"
              ]
            }
          },
          "varname": "cpRate"
        }
      },
      {
        "box": {
          "id": "rate_index-pre",
          "maxclass": "newobj",
          "text": "prepend rate_index",
          "patching_rect": [
            500.0,
            268.0,
            120.0,
            22.0
          ]
        }
      },
      {
        "box": {
          "id": "length-label",
          "maxclass": "comment",
          "text": "LEN",
          "patching_rect": [
            300.0,
            260.0,
            100.0,
            18.0
          ],
          "presentation": 1,
          "presentation_rect": [
            101.0,
            0.0,
            44.0,
            10.0
          ],
          "fontsize": 8.0,
          "textjustification": 1
        }
      },
      {
        "box": {
          "id": "length",
          "maxclass": "live.menu",
          "numinlets": 1,
          "numoutlets": 2,
          "outlettype": [
            "",
            "float"
          ],
          "parameter_enable": 1,
          "patching_rect": [
            300.0,
            312.0,
            80.0,
            22.0
          ],
          "presentation": 1,
          "presentation_rect": [
            101.0,
            10.0,
            44.0,
            16.0
          ],
          "saved_attribute_attributes": {
            "valueof": {
              "parameter_initial": [
                3
              ],
              "parameter_initial_enable": 1,
              "parameter_longname": "Cymbal Phrase Length",
              "parameter_mmax": 6.0,
              "parameter_mmin": 0.0,
              "parameter_modmode": 0,
              "parameter_shortname": "Length",
              "parameter_type": 2,
              "parameter_enum": [
                "1 bar",
                "2 bars",
                "4 bars",
                "8 bars",
                "16 bars",
                "32 bars",
                "64 bars"
              ]
            }
          },
          "varname": "cpLength"
        }
      },
      {
        "box": {
          "id": "length_index-pre",
          "maxclass": "newobj",
          "text": "prepend length_index",
          "patching_rect": [
            500.0,
            334.0,
            120.0,
            22.0
          ]
        }
      },
      {
        "box": {
          "id": "density",
          "maxclass": "live.dial",
          "numinlets": 1,
          "numoutlets": 2,
          "outlettype": [
            "",
            "float"
          ],
          "parameter_enable": 1,
          "patching_rect": [
            300.0,
            356.0,
            80.0,
            22.0
          ],
          "presentation": 1,
          "presentation_rect": [
            5.0,
            31.0,
            44.0,
            50.0
          ],
          "saved_attribute_attributes": {
            "valueof": {
              "parameter_initial": [
                58
              ],
              "parameter_initial_enable": 1,
              "parameter_longname": "Cymbal Phrase Density",
              "parameter_mmax": 100.0,
              "parameter_mmin": 0.0,
              "parameter_modmode": 3,
              "parameter_shortname": "Density",
              "parameter_type": 0,
              "parameter_unitstyle": 5
            }
          },
          "varname": "cpDensity"
        }
      },
      {
        "box": {
          "id": "density-pre",
          "maxclass": "newobj",
          "text": "prepend density",
          "patching_rect": [
            500.0,
            378.0,
            120.0,
            22.0
          ]
        }
      },
      {
        "box": {
          "id": "air",
          "maxclass": "live.dial",
          "numinlets": 1,
          "numoutlets": 2,
          "outlettype": [
            "",
            "float"
          ],
          "parameter_enable": 1,
          "patching_rect": [
            300.0,
            400.0,
            80.0,
            22.0
          ],
          "presentation": 1,
          "presentation_rect": [
            53.0,
            31.0,
            44.0,
            50.0
          ],
          "saved_attribute_attributes": {
            "valueof": {
              "parameter_initial": [
                32
              ],
              "parameter_initial_enable": 1,
              "parameter_longname": "Cymbal Phrase Air",
              "parameter_mmax": 100.0,
              "parameter_mmin": 0.0,
              "parameter_modmode": 3,
              "parameter_shortname": "Air",
              "parameter_type": 0,
              "parameter_unitstyle": 5
            }
          },
          "varname": "cpAir"
        }
      },
      {
        "box": {
          "id": "air-pre",
          "maxclass": "newobj",
          "text": "prepend air",
          "patching_rect": [
            500.0,
            422.0,
            120.0,
            22.0
          ]
        }
      },
      {
        "box": {
          "id": "accent",
          "maxclass": "live.dial",
          "numinlets": 1,
          "numoutlets": 2,
          "outlettype": [
            "",
            "float"
          ],
          "parameter_enable": 1,
          "patching_rect": [
            300.0,
            444.0,
            80.0,
            22.0
          ],
          "presentation": 1,
          "presentation_rect": [
            101.0,
            31.0,
            44.0,
            50.0
          ],
          "saved_attribute_attributes": {
            "valueof": {
              "parameter_initial": [
                64
              ],
              "parameter_initial_enable": 1,
              "parameter_longname": "Cymbal Phrase Accent",
              "parameter_mmax": 100.0,
              "parameter_mmin": 0.0,
              "parameter_modmode": 3,
              "parameter_shortname": "Accent",
              "parameter_type": 0,
              "parameter_unitstyle": 5
            }
          },
          "varname": "cpAccent"
        }
      },
      {
        "box": {
          "id": "accent-pre",
          "maxclass": "newobj",
          "text": "prepend accent",
          "patching_rect": [
            500.0,
            466.0,
            120.0,
            22.0
          ]
        }
      },
      {
        "box": {
          "id": "pocket",
          "maxclass": "live.dial",
          "numinlets": 1,
          "numoutlets": 2,
          "outlettype": [
            "",
            "float"
          ],
          "parameter_enable": 1,
          "patching_rect": [
            300.0,
            488.0,
            80.0,
            22.0
          ],
          "presentation": 1,
          "presentation_rect": [
            5.0,
            83.0,
            44.0,
            50.0
          ],
          "saved_attribute_attributes": {
            "valueof": {
              "parameter_initial": [
                18
              ],
              "parameter_initial_enable": 1,
              "parameter_longname": "Cymbal Phrase Pocket",
              "parameter_mmax": 100.0,
              "parameter_mmin": 0.0,
              "parameter_modmode": 3,
              "parameter_shortname": "Pocket",
              "parameter_type": 0,
              "parameter_unitstyle": 5
            }
          },
          "varname": "cpPocket"
        }
      },
      {
        "box": {
          "id": "pocket-pre",
          "maxclass": "newobj",
          "text": "prepend pocket",
          "patching_rect": [
            500.0,
            510.0,
            120.0,
            22.0
          ]
        }
      },
      {
        "box": {
          "id": "evolve",
          "maxclass": "live.dial",
          "numinlets": 1,
          "numoutlets": 2,
          "outlettype": [
            "",
            "float"
          ],
          "parameter_enable": 1,
          "patching_rect": [
            300.0,
            532.0,
            80.0,
            22.0
          ],
          "presentation": 1,
          "presentation_rect": [
            53.0,
            83.0,
            44.0,
            50.0
          ],
          "saved_attribute_attributes": {
            "valueof": {
              "parameter_initial": [
                24
              ],
              "parameter_initial_enable": 1,
              "parameter_longname": "Cymbal Phrase Evolve",
              "parameter_mmax": 100.0,
              "parameter_mmin": 0.0,
              "parameter_modmode": 3,
              "parameter_shortname": "Evolve",
              "parameter_type": 0,
              "parameter_unitstyle": 5
            }
          },
          "varname": "cpEvolve"
        }
      },
      {
        "box": {
          "id": "evolve-pre",
          "maxclass": "newobj",
          "text": "prepend evolve",
          "patching_rect": [
            500.0,
            554.0,
            120.0,
            22.0
          ]
        }
      },
      {
        "box": {
          "id": "new-phrase",
          "maxclass": "message",
          "text": "new_phrase",
          "patching_rect": [
            40.0,
            250.0,
            100.0,
            22.0
          ]
        }
      },
      {
        "box": {
          "id": "new-phrase-button",
          "maxclass": "button",
          "patching_rect": [
            40.0,
            250.0,
            32.0,
            32.0
          ],
          "presentation": 1,
          "presentation_rect": [
            110.0,
            84.0,
            26.0,
            26.0
          ]
        }
      },
      {
        "box": {
          "id": "dice-face",
          "maxclass": "panel",
          "patching_rect": [
            80.0,
            250.0,
            26.0,
            26.0
          ],
          "presentation": 1,
          "ignoreclick": 1,
          "border": 1,
          "bgfillcolor": [
            0.18,
            0.18,
            0.18,
            1.0
          ],
          "shape": 0,
          "presentation_rect": [
            110.0,
            84.0,
            26.0,
            26.0
          ],
          "rounded": 5,
          "bordercolor": [
            0.62,
            0.62,
            0.62,
            1.0
          ]
        }
      },
      {
        "box": {
          "id": "dice-pip-1",
          "maxclass": "panel",
          "patching_rect": [
            80.0,
            250.0,
            4.0,
            4.0
          ],
          "presentation": 1,
          "ignoreclick": 1,
          "border": 0,
          "bgfillcolor": [
            0.82,
            0.82,
            0.82,
            1.0
          ],
          "shape": 1,
          "presentation_rect": [
            115.0,
            89.0,
            4.0,
            4.0
          ]
        }
      },
      {
        "box": {
          "id": "dice-pip-2",
          "maxclass": "panel",
          "patching_rect": [
            80.0,
            250.0,
            4.0,
            4.0
          ],
          "presentation": 1,
          "ignoreclick": 1,
          "border": 0,
          "bgfillcolor": [
            0.82,
            0.82,
            0.82,
            1.0
          ],
          "shape": 1,
          "presentation_rect": [
            127.0,
            89.0,
            4.0,
            4.0
          ]
        }
      },
      {
        "box": {
          "id": "dice-pip-3",
          "maxclass": "panel",
          "patching_rect": [
            80.0,
            250.0,
            4.0,
            4.0
          ],
          "presentation": 1,
          "ignoreclick": 1,
          "border": 0,
          "bgfillcolor": [
            0.82,
            0.82,
            0.82,
            1.0
          ],
          "shape": 1,
          "presentation_rect": [
            121.0,
            95.0,
            4.0,
            4.0
          ]
        }
      },
      {
        "box": {
          "id": "dice-pip-4",
          "maxclass": "panel",
          "patching_rect": [
            80.0,
            250.0,
            4.0,
            4.0
          ],
          "presentation": 1,
          "ignoreclick": 1,
          "border": 0,
          "bgfillcolor": [
            0.82,
            0.82,
            0.82,
            1.0
          ],
          "shape": 1,
          "presentation_rect": [
            115.0,
            101.0,
            4.0,
            4.0
          ]
        }
      },
      {
        "box": {
          "id": "dice-pip-5",
          "maxclass": "panel",
          "patching_rect": [
            80.0,
            250.0,
            4.0,
            4.0
          ],
          "presentation": 1,
          "ignoreclick": 1,
          "border": 0,
          "bgfillcolor": [
            0.82,
            0.82,
            0.82,
            1.0
          ],
          "shape": 1,
          "presentation_rect": [
            127.0,
            101.0,
            4.0,
            4.0
          ]
        }
      },
      {
        "box": {
          "id": "new-phrase-label",
          "maxclass": "comment",
          "text": "NEW",
          "patching_rect": [
            300.0,
            722.0,
            100.0,
            18.0
          ],
          "presentation": 1,
          "presentation_rect": [
            101.0,
            113.0,
            44.0,
            16.0
          ],
          "fontsize": 8.0,
          "ignoreclick": 1
        }
      }
    ],
    "lines": [
      {
        "patchline": {
          "source": [
            "in",
            0
          ],
          "destination": [
            "generator",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "generator",
            0
          ],
          "destination": [
            "out",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "transaction",
            1
          ],
          "destination": [
            "generator",
            1
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "transaction",
            0
          ],
          "destination": [
            "in",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "motion",
            0
          ],
          "destination": [
            "motion-pre",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "motion-pre",
            0
          ],
          "destination": [
            "transaction",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "rate",
            0
          ],
          "destination": [
            "rate-pre",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "rate-pre",
            0
          ],
          "destination": [
            "transaction",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "length",
            0
          ],
          "destination": [
            "length-pre",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "length-pre",
            0
          ],
          "destination": [
            "transaction",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "density",
            0
          ],
          "destination": [
            "density-pre",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "density-pre",
            0
          ],
          "destination": [
            "transaction",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "air",
            0
          ],
          "destination": [
            "air-pre",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "air-pre",
            0
          ],
          "destination": [
            "transaction",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "accent",
            0
          ],
          "destination": [
            "accent-pre",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "accent-pre",
            0
          ],
          "destination": [
            "transaction",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "pocket",
            0
          ],
          "destination": [
            "pocket-pre",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "pocket-pre",
            0
          ],
          "destination": [
            "transaction",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "evolve",
            0
          ],
          "destination": [
            "evolve-pre",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "evolve-pre",
            0
          ],
          "destination": [
            "transaction",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "new-phrase-button",
            0
          ],
          "destination": [
            "new-phrase",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "new-phrase",
            0
          ],
          "destination": [
            "transaction",
            0
          ]
        }
      }
    ],
    "parameters": {
      "motion": [
        "Cymbal Phrase Motion",
        "Motion",
        0
      ],
      "rate": [
        "Cymbal Phrase Rate",
        "Rate",
        0
      ],
      "density": [
        "Cymbal Phrase Density",
        "Density",
        0
      ],
      "air": [
        "Cymbal Phrase Air",
        "Air",
        0
      ],
      "accent": [
        "Cymbal Phrase Accent",
        "Accent",
        0
      ],
      "pocket": [
        "Cymbal Phrase Pocket",
        "Pocket",
        0
      ],
      "evolve": [
        "Cymbal Phrase Evolve",
        "Evolve",
        0
      ],
      "length": [
        "Cymbal Phrase Length",
        "Length",
        0
      ],
      "parameterbanks": {
        "0": {
          "index": 0,
          "name": "",
          "parameters": [
            "motion",
            "rate",
            "density",
            "air",
            "accent",
            "pocket",
            "evolve",
            "length"
          ]
        }
      },
      "inherited_shortname": 1
    },
    "dependency_cache": []
  }
}
