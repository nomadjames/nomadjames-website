# Cymbal Phrase CP-004 public beta

Cymbal Phrase is a Max for Live 12 MIDI Generator Tool for making deterministic hat, crash, and ride phrases that can develop across 1 to 64 bars.

## Install

1. Download `Cymbal-Phrase-CP-004.amxd`.
2. Open Ableton Live 12. Max for Live must be installed.
3. Drag the `.amxd` file into **User Library** in Live's Browser. You can also copy it to `Music/Ableton/User Library/MIDI Tools/Max Generators` inside your home folder.
4. Give Live a moment to index the file. If it does not appear immediately after startup, wait for the User Library scan to settle before copying it again.
5. Select a MIDI clip, open the clip's **Generate** panel, and choose **Cymbal Phrase** from the User section.
6. Choose Motion, Rate, and Length. Shape the result with Density, Air, Accent, Pocket, and Evolve. Click **New** for a new deterministic phrase, then click Live's Apply icon.

## Drum Rack mapping

The default map targets the hat, crash, and ride lanes from the stock 16-pad Ableton rack used during Live testing:

- closed hat 42
- open hat 46
- crashes 48 and 49
- rides 50 and 51

Drum Rack mappings are preset-dependent. CP-004 does not claim universal compatibility with every factory or custom rack. The generator excludes the observed tom lanes 44, 45, and 47. If your rack uses different note assignments, remap the rack or edit the source map before use.

Live MIDI Tools do not run on Push Standalone. Push support refers to Control Mode with Live.

## Status

CP-004 passed 18 machine tests, including a 64-seed by 64-bar sweep with no output on the excluded tom lanes and no duplicate pitch/start stacks after voice folding. The latest hands-on Live report says it appears stable and works well. This release remains a public beta until layout, rack mapping, New, Push Control Mode banking, and the musical result receive explicit final acceptance.

## Build and test

```sh
npm test
npm run check
npm run validate
```

The build regenerates the Max patch from source, embeds the tested Max 9 V8 engine, writes the `.amxd`, and round-trip validates its patch chunk.

## License and authorship

MIT licensed. James Dishman directed the research question, product, musical goals, Live testing, and listening decisions. Clarence assisted with research synthesis, code, tests, packaging, and documentation under James's direction and review.
