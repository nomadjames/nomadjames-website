#!/usr/bin/env node
'use strict';

var fs = require('node:fs');
var path = require('node:path');
var root = path.resolve(__dirname, '..');
var patcher = JSON.parse(fs.readFileSync(path.join(root, 'max/rhythm-dice.maxpat'), 'utf8')).patcher;
var boxes = patcher.boxes.map(function (entry) { return entry.box; });
var lines = patcher.lines.map(function (entry) { return entry.patchline; });
var maxSource = fs.readFileSync(path.join(root, 'max/rd_generator.js'), 'utf8');
var coreSource = fs.readFileSync(path.join(root, 'src/rhythm-dice.js'), 'utf8');
function box(id) {
  return boxes.filter(function (item) { return item.id === id; })[0];
}
function connected(source, sourceOutlet, destination, destinationInlet) {
  return lines.some(function (line) {
    return line.source[0] === source && line.source[1] === sourceOutlet &&
      line.destination[0] === destination && line.destination[1] === destinationInlet;
  });
}
function assert(condition, message) {
  if (!condition) throw new Error(message);
}
assert(box('in').text === 'live.miditool.in', 'missing live.miditool.in');
assert(box('out').text === 'live.miditool.out', 'missing live.miditool.out');
assert(patcher.devicewidth <= 150, 'device presentation is wider than the measured Live MIDI Tool panel');
boxes.filter(function (item) { return item.presentation === 1; }).forEach(function (item) {
  assert(item.presentation_rect[0] + item.presentation_rect[2] <= 150, item.id + ' is clipped by the measured Live MIDI Tool panel');
});
assert(box('generator').text === 'v8', 'generator is not an embedded Max 9 v8 object');
assert(box('generator').textfile && box('generator').textfile.embed === 1, 'generator source is not embedded');
assert(box('generator').textfile.text === maxSource, 'embedded generator source differs from tested source');
assert(box('transaction').text === 't b l', 'transaction must forward the setting list before banging live.miditool.in');
assert(connected('in', 0, 'generator', 0), 'input is not connected to generator');
assert(connected('generator', 0, 'out', 0), 'generator is not connected to output');
assert(connected('transaction', 1, 'generator', 1), 'settings are not applied before transaction');
assert(connected('transaction', 0, 'in', 0), 'control changes do not start at live.miditool.in');
assert(connected('apply-button', 0, 'roll', 0), 'drawn dice button does not advance the seed');
assert(!connected('apply-button', 0, 'in', 0), 'regenerate button bypasses the seed roll');
assert(patcher.openinpresentation === 1, 'patcher does not open in presentation mode');
['family', 'seed', 'bars', 'density', 'feel', 'humanize', 'fill'].forEach(function (id) {
  assert(!!box(id), 'missing control: ' + id);
  assert(box(id).parameter_enable === 1, id + ' is not a Live parameter');
  assert(box(id).presentation === 1 && Array.isArray(box(id).presentation_rect), id + ' is not visible in presentation');
  assert(box(id).presentation_rect[0] + box(id).presentation_rect[2] <= 260, id + ' is clipped by the Live MIDI Tool panel');
  assert(box(id).saved_attribute_attributes && box(id).saved_attribute_attributes.valueof, id + ' is missing parameter metadata');
  assert(patcher.parameters && patcher.parameters[id], id + ' is missing from patcher parameters');
});
assert(box('family').saved_attribute_attributes.valueof.parameter_enum.length === 9, 'family menu is incomplete');
assert(box('bars').saved_attribute_attributes.valueof.parameter_enum.length === 4, 'bars menu is incomplete');
assert(box('fill').saved_attribute_attributes.valueof.parameter_enum.length === 3, 'fill menu is incomplete');
assert(box('family-pre').text === 'prepend family_index', 'family selector is not v8-safe');
assert(box('bars-pre').text === 'prepend bars_index', 'bars selector is not v8-safe');
assert(box('fill-pre').text === 'prepend fill_index', 'fill selector is not v8-safe');
['density-label', 'feel-label', 'humanize-label', 'roll-button', 'roll-label'].forEach(function (id) {
  assert(box(id).presentation !== 1, id + ' should not clutter presentation');
});
assert(box('apply-label').text === 'ROLL THE DICE', 'dice action label is missing');
assert(box('apply-label').presentation === 1, 'dice action label is hidden');
assert(box('dice-face') && box('dice-face').maxclass === 'panel', 'drawn dice face is missing');
assert(box('dice-face').ignoreclick === 1, 'dice face blocks the working button');
['dice-pip-1', 'dice-pip-2', 'dice-pip-3', 'dice-pip-4', 'dice-pip-5'].forEach(function (id) {
  assert(box(id) && box(id).maxclass === 'panel' && box(id).shape === 1, id + ' is not a circular dice pip');
  assert(box(id).presentation === 1 && box(id).ignoreclick === 1, id + ' is not safely drawn in presentation');
});
['density-pre', 'feel-pre', 'humanize-pre', 'family-pre', 'seed-pre', 'bars-pre', 'fill-pre'].forEach(function (id) {
  assert(connected(id, 0, 'transaction', 0), id + ' bypasses the transaction trigger');
});
assert(connected('roll', 0, 'transaction', 0), 'roll bypasses the transaction trigger');
assert(!boxes.some(function (item) { return String(item.text || '').indexOf('node.script') !== -1; }), 'node.script is not allowed');
assert(!patcher.dependency_cache.some(function (item) { return item.name === 'rd_generator.js'; }), 'external generator dependency remains');
assert(maxSource.indexOf(coreSource) === 0, 'Max core has drifted from tested portable core');
['family', 'family_index', 'seed', 'bars', 'bars_index', 'density', 'feel', 'humanize', 'fill', 'fill_index', 'roll', 'msg_dictionary'].forEach(function (handler) {
  assert(maxSource.indexOf('function ' + handler + '(') !== -1, 'missing Max 9 handler: ' + handler);
});
assert(maxSource.indexOf('outlet_dictionary(0,') !== -1, 'generator does not use Max 9 v8 dictionary output');
assert(maxSource.indexOf('new Dict(') === -1, 'legacy Dict output remains');
assert(maxSource.indexOf('function anything()') === -1, 'legacy anything dispatcher remains');
console.log(JSON.stringify({ boxes: boxes.length, connections: lines.length, controls: 7, engine: 'embedded Max 9 v8', width: patcher.devicewidth, transaction: 'setting -> t b l (list first) -> live.miditool.in -> v8 -> live.miditool.out' }));
