#!/usr/bin/env python3
"""Embed Rhythm Dice logic and compact its MIDI Tool UI."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

DEVICE_WIDTH = 150.0
TRANSACTION_TEXT = "t b l"

SELECTOR_TEXT = {
    "family-pre": "prepend family_index",
    "bars-pre": "prepend bars_index",
    "fill-pre": "prepend fill_index",
}

PRESENTATION: dict[str, tuple[list[float], str | None]] = {
    "family-label": ([5.0, 0.0, 55.0, 14.0], None),
    "family": ([5.0, 14.0, 90.0, 15.0], None),
    "bars-label": ([100.0, 0.0, 42.0, 14.0], None),
    "bars": ([100.0, 14.0, 43.0, 15.0], None),
    "seed-label": ([5.0, 31.0, 40.0, 14.0], None),
    "seed": ([5.0, 45.0, 65.0, 15.0], None),
    "fill-label": ([75.0, 31.0, 35.0, 14.0], None),
    "fill": ([75.0, 45.0, 50.0, 15.0], None),
    "density": ([5.0, 64.0, 44.0, 50.0], None),
    "feel": ([53.0, 64.0, 44.0, 50.0], None),
    "humanize": ([101.0, 64.0, 44.0, 50.0], None),
    "apply-button": ([5.0, 116.0, 26.0, 24.0], None),
    "apply-label": ([36.0, 119.0, 105.0, 18.0], "ROLL THE DICE"),
}

HIDDEN_PRESENTATION = {
    "density-label",
    "feel-label",
    "humanize-label",
    "roll-button",
    "roll-label",
}

DICE_PANELS: dict[str, dict[str, Any]] = {
    "dice-face": {
        "presentation_rect": [5.0, 115.0, 26.0, 26.0],
        "shape": 0,
        "rounded": 5,
        "border": 1,
        "bordercolor": [0.62, 0.62, 0.62, 1.0],
        "bgfillcolor": [0.18, 0.18, 0.18, 1.0],
    },
    "dice-pip-1": {"presentation_rect": [10.0, 120.0, 4.0, 4.0], "shape": 1},
    "dice-pip-2": {"presentation_rect": [22.0, 120.0, 4.0, 4.0], "shape": 1},
    "dice-pip-3": {"presentation_rect": [16.0, 126.0, 4.0, 4.0], "shape": 1},
    "dice-pip-4": {"presentation_rect": [10.0, 132.0, 4.0, 4.0], "shape": 1},
    "dice-pip-5": {"presentation_rect": [22.0, 132.0, 4.0, 4.0], "shape": 1},
}


def transform(document: dict[str, Any], source: str) -> list[str]:
    patcher = document["patcher"]
    boxes = {entry["box"]["id"]: entry["box"] for entry in patcher["boxes"]}
    missing = sorted(
        ({"generator", "transaction"} | set(PRESENTATION) | set(HIDDEN_PRESENTATION) | set(SELECTOR_TEXT))
        - set(boxes)
    )
    if missing:
        raise ValueError(f"missing expected Rhythm Dice boxes: {missing}")

    changes: list[str] = []
    if boxes["transaction"].get("text") != TRANSACTION_TEXT:
        boxes["transaction"]["text"] = TRANSACTION_TEXT
        changes.append("replace literal anything constant with ordered t b l transaction")
    if patcher.get("devicewidth") != DEVICE_WIDTH:
        patcher["devicewidth"] = DEVICE_WIDTH
        changes.append(f"set devicewidth={DEVICE_WIDTH}")

    generator = boxes["generator"]
    embedded = {
        "text": source,
        "filename": "none",
        "flags": 0,
        "embed": 1,
        "autowatch": 1,
    }
    if generator.get("text") != "v8" or generator.get("textfile") != embedded:
        generator["text"] = "v8"
        generator["filename"] = "none"
        generator["textfile"] = embedded
        generator["saved_object_attributes"] = {"parameter_enable": 0}
        changes.append("replace external js object with embedded Max 9 v8 source")

    dependencies = patcher.get("dependency_cache", [])
    filtered = [item for item in dependencies if item.get("name") != "rd_generator.js"]
    if filtered != dependencies:
        patcher["dependency_cache"] = filtered
        changes.append("remove external rd_generator.js dependency")

    for box_id, text in SELECTOR_TEXT.items():
        if boxes[box_id].get("text") != text:
            boxes[box_id]["text"] = text
            changes.append(f"set Max 9 message selector {text}")

    for box_id in HIDDEN_PRESENTATION:
        if boxes[box_id].get("presentation") == 1:
            boxes[box_id]["presentation"] = 0
            changes.append(f"remove redundant {box_id} from presentation")

    human_value = boxes["humanize"]["saved_attribute_attributes"]["valueof"]
    if human_value.get("parameter_shortname") != "Human":
        human_value["parameter_shortname"] = "Human"
        patcher["parameters"]["humanize"][1] = "Human"
        changes.append("shorten Humanize display label to Human")

    for index, (box_id, style) in enumerate(DICE_PANELS.items()):
        desired = {
            "id": box_id,
            "maxclass": "panel",
            "patching_rect": [820.0 + index * 12.0, 320.0, 10.0, 10.0],
            "presentation": 1,
            "ignoreclick": 1,
            "border": style.get("border", 0),
            "bgfillcolor": style.get("bgfillcolor", [0.82, 0.82, 0.82, 1.0]),
            "shape": style["shape"],
            "presentation_rect": style["presentation_rect"],
        }
        for optional in ("rounded", "bordercolor"):
            if optional in style:
                desired[optional] = style[optional]
        if box_id not in boxes:
            patcher["boxes"].append({"box": desired})
            boxes[box_id] = desired
            changes.append(f"draw {box_id}")
        else:
            current = boxes[box_id]
            if any(current.get(key) != value for key, value in desired.items()):
                current.update(desired)
                changes.append(f"repair drawn {box_id}")

    for box_id, (rect, replacement_text) in PRESENTATION.items():
        box = boxes[box_id]
        if box.get("presentation_rect") != rect:
            box["presentation_rect"] = rect
            changes.append(f"place {box_id} inside MIDI Tool panel")
        if replacement_text is not None and box.get("text") != replacement_text:
            box["text"] = replacement_text
            changes.append(f"rename {box_id} to {replacement_text}")

    return changes


def validate(document: dict[str, Any], source: str) -> None:
    patcher = document["patcher"]
    boxes = {entry["box"]["id"]: entry["box"] for entry in patcher["boxes"]}
    generator = boxes["generator"]
    assert boxes["transaction"]["text"] == TRANSACTION_TEXT
    assert patcher["devicewidth"] == DEVICE_WIDTH
    assert generator["text"] == "v8"
    assert generator["filename"] == "none"
    assert generator["textfile"]["embed"] == 1
    assert generator["textfile"]["text"] == source
    assert not any(item.get("name") == "rd_generator.js" for item in patcher["dependency_cache"])
    for box_id, text in SELECTOR_TEXT.items():
        assert boxes[box_id]["text"] == text
    for box_id in HIDDEN_PRESENTATION:
        assert boxes[box_id].get("presentation") != 1
    assert boxes["humanize"]["saved_attribute_attributes"]["valueof"]["parameter_shortname"] == "Human"
    assert patcher["parameters"]["humanize"][1] == "Human"
    for box_id in DICE_PANELS:
        box = boxes[box_id]
        assert box["maxclass"] == "panel"
        assert box["presentation"] == 1
        assert box["ignoreclick"] == 1
    for box_id in PRESENTATION:
        box = boxes[box_id]
        assert box["presentation"] == 1
        x, _, width, _ = box["presentation_rect"]
        assert x >= 0
        assert x + width <= DEVICE_WIDTH


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("patch", type=Path)
    parser.add_argument("javascript", type=Path)
    args = parser.parse_args()

    document = json.loads(args.patch.read_text(encoding="utf-8"))
    source = args.javascript.read_text(encoding="utf-8")
    changes = transform(document, source)
    validate(document, source)

    rendered = json.dumps(document, ensure_ascii=False, indent=2) + "\n"
    args.patch.write_text(rendered, encoding="utf-8")
    print(json.dumps({"patch": str(args.patch), "changes": changes}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
