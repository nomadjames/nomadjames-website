#!/usr/bin/env python3
"""Repair the known Rhythm Dice AMXD packaging defects.

The AMXD variant emitted by Max 9 here is an `ampf` container with a
12-byte header followed by little-endian length-prefixed chunks. The `ptch`
chunk is UTF-8 Max patch JSON terminated by a NUL byte.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import struct
import sys
from typing import Any

from embed_v8 import DEVICE_WIDTH, transform as embed_transform, validate as validate_embedded

HEADER_SIZE = 12
EXPECTED_HEADER_PREFIX = b"ampf"
EXPECTED_CONTAINER_KIND = b"nagg"
CONTROL_IDS = ["family", "seed", "bars", "density", "feel", "humanize", "fill"]
PARAMETER_BANK = CONTROL_IDS + ["-"]


def parse_container(data: bytes) -> tuple[bytes, list[tuple[bytes, bytes]]]:
    if len(data) < HEADER_SIZE:
        raise ValueError("AMXD is shorter than its container header")
    header = data[:HEADER_SIZE]
    if header[:4] != EXPECTED_HEADER_PREFIX:
        raise ValueError(f"unexpected AMXD magic: {header[:4]!r}")
    if header[8:12] != EXPECTED_CONTAINER_KIND:
        raise ValueError(f"unsupported AMXD container kind: {header[8:12]!r}")

    chunks: list[tuple[bytes, bytes]] = []
    position = HEADER_SIZE
    while position < len(data):
        if position + 8 > len(data):
            raise ValueError("truncated AMXD chunk header")
        chunk_id = data[position : position + 4]
        chunk_size = struct.unpack_from("<I", data, position + 4)[0]
        payload_start = position + 8
        payload_end = payload_start + chunk_size
        if payload_end > len(data):
            raise ValueError(f"truncated {chunk_id!r} AMXD chunk")
        chunks.append((chunk_id, data[payload_start:payload_end]))
        position = payload_end
    return header, chunks


def patch_from_chunks(chunks: list[tuple[bytes, bytes]]) -> dict[str, Any]:
    patch_payloads = [payload for chunk_id, payload in chunks if chunk_id == b"ptch"]
    if len(patch_payloads) != 1:
        raise ValueError(f"expected exactly one ptch chunk, found {len(patch_payloads)}")
    return json.loads(patch_payloads[0].rstrip(b"\x00").decode("utf-8"))


def line_signature(line: dict[str, Any]) -> tuple[tuple[Any, ...], tuple[Any, ...]]:
    patchline = line["patchline"]
    return tuple(patchline["source"]), tuple(patchline["destination"])


def repair_patch(document: dict[str, Any], javascript_source: str) -> list[str]:
    patcher = document.get("patcher")
    if not isinstance(patcher, dict):
        raise ValueError("ptch chunk has no patcher object")

    boxes = {entry["box"].get("id"): entry["box"] for entry in patcher.get("boxes", [])}
    required_ids = {
        "in",
        "out",
        "generator",
        "transaction",
        "apply-button",
        "roll",
        *CONTROL_IDS,
    }
    missing = sorted(required_ids - set(boxes))
    if missing:
        raise ValueError(f"not the expected Rhythm Dice patch; missing boxes: {missing}")
    if boxes["in"].get("text") != "live.miditool.in":
        raise ValueError("unexpected MIDI Tool input object")
    if boxes["out"].get("text") != "live.miditool.out":
        raise ValueError("unexpected MIDI Tool output object")
    if boxes["generator"].get("text") not in {"js rd_generator.js", "v8"}:
        raise ValueError("unexpected Rhythm Dice generator object")

    changes: list[str] = []
    if patcher.get("openinpresentation") != 1:
        patcher["openinpresentation"] = 1
        changes.append("set openinpresentation=1")

    expected_line = (("transaction", 1), ("generator", 1))
    existing_lines = {line_signature(line) for line in patcher.get("lines", [])}
    if expected_line not in existing_lines:
        patcher.setdefault("lines", []).append(
            {
                "patchline": {
                    "source": ["transaction", 1],
                    "destination": ["generator", 1],
                }
            }
        )
        changes.append("restore settings connection transaction[1] -> generator[1]")

    stale_apply_line = (("apply-button", 0), ("in", 0))
    reroll_line = (("apply-button", 0), ("roll", 0))
    if stale_apply_line in existing_lines:
        patcher["lines"] = [
            line for line in patcher["lines"] if line_signature(line) != stale_apply_line
        ]
        existing_lines.remove(stale_apply_line)
        changes.append("remove idempotent regenerate connection apply-button[0] -> in[0]")
    if reroll_line not in existing_lines:
        patcher.setdefault("lines", []).append(
            {
                "patchline": {
                    "source": ["apply-button", 0],
                    "destination": ["roll", 0],
                }
            }
        )
        changes.append("connect regenerate button to seed roll")

    parameters = patcher.setdefault("parameters", {})
    parameterbanks = parameters.setdefault("parameterbanks", {})
    bank_zero = parameterbanks.setdefault("0", {"index": 0, "name": ""})
    if bank_zero.get("parameters") != PARAMETER_BANK:
        bank_zero["parameters"] = PARAMETER_BANK.copy()
        changes.append("restore Live parameter bank")

    changes.extend(embed_transform(document, javascript_source))

    return changes


def validate_patch(document: dict[str, Any], javascript_source: str) -> dict[str, Any]:
    patcher = document["patcher"]
    boxes = {entry["box"].get("id"): entry["box"] for entry in patcher["boxes"]}
    lines = {line_signature(line) for line in patcher["lines"]}

    assert patcher.get("openinpresentation") == 1
    validate_embedded(document, javascript_source)
    for control_id in CONTROL_IDS:
        control = boxes[control_id]
        assert control.get("presentation") == 1
        assert isinstance(control.get("presentation_rect"), list)
        assert control.get("parameter_enable") == 1
    assert (("transaction", 1), ("generator", 1)) in lines
    assert (("transaction", 0), ("in", 0)) in lines
    assert (("in", 0), ("generator", 0)) in lines
    assert (("generator", 0), ("out", 0)) in lines
    assert (("apply-button", 0), ("roll", 0)) in lines
    assert (("apply-button", 0), ("in", 0)) not in lines
    assert patcher["parameters"]["parameterbanks"]["0"]["parameters"] == PARAMETER_BANK

    return {
        "openinpresentation": patcher["openinpresentation"],
        "devicewidth": patcher["devicewidth"],
        "controls_in_presentation": len(CONTROL_IDS),
        "connections": len(lines),
        "parameter_bank": patcher["parameters"]["parameterbanks"]["0"]["parameters"],
        "embedded_engine": "Max 9 v8",
        "embedded_javascript_bytes": len(javascript_source.encode("utf-8")),
        "regenerate_path": "apply-button -> roll -> transaction -> live.miditool.in",
    }


def serialize_patch(document: dict[str, Any], nul_terminated: bool) -> bytes:
    payload = (json.dumps(document, ensure_ascii=False, indent="\t") + "\n").encode("utf-8")
    if nul_terminated:
        payload += b"\x00"
    return payload


def rebuild_container(header: bytes, chunks: list[tuple[bytes, bytes]], document: dict[str, Any]) -> bytes:
    original_patch = next(payload for chunk_id, payload in chunks if chunk_id == b"ptch")
    replacement = serialize_patch(document, original_patch.endswith(b"\x00"))
    output = bytearray(header)
    for chunk_id, payload in chunks:
        if chunk_id == b"ptch":
            payload = replacement
        output.extend(chunk_id)
        output.extend(struct.pack("<I", len(payload)))
        output.extend(payload)
    return bytes(output)


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument(
        "--javascript",
        type=Path,
        default=Path(__file__).resolve().parent.parent / "max" / "rd_generator.js",
    )
    args = parser.parse_args()

    javascript_source = args.javascript.read_text(encoding="utf-8")
    original = args.input.read_bytes()
    header, chunks = parse_container(original)
    document = patch_from_chunks(chunks)
    changes = repair_patch(document, javascript_source)
    validation = validate_patch(document, javascript_source)
    repaired = rebuild_container(header, chunks, document)

    # Verify the bytes that will actually be delivered, not only the in-memory patch.
    rebuilt_header, rebuilt_chunks = parse_container(repaired)
    if rebuilt_header != header:
        raise AssertionError("container header changed")
    rebuilt_document = patch_from_chunks(rebuilt_chunks)
    rebuilt_validation = validate_patch(rebuilt_document, javascript_source)
    if rebuilt_validation != validation:
        raise AssertionError("serialized AMXD failed round-trip validation")

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_bytes(repaired)
    print(
        json.dumps(
            {
                "input": str(args.input),
                "output": str(args.output),
                "input_sha256": sha256(original),
                "output_sha256": sha256(repaired),
                "changes": changes,
                "validation": validation,
            },
            indent=2,
        )
    )
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (AssertionError, KeyError, TypeError, ValueError) as error:
        print(f"repair failed: {error}", file=sys.stderr)
        raise SystemExit(1)
