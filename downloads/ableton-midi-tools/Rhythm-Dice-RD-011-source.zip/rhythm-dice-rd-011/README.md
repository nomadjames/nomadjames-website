# Rhythm Dice RD-011

Rhythm Dice is a Max for Live 12 MIDI Generator Tool for building drum patterns from eight musical rhythm families. The same settings and seed produce the same notes. Roll the die to advance the seed and make a new pattern.

## Install

1. Download `Rhythm-Dice-RD-011.amxd`.
2. Open Ableton Live 12. Max for Live must be installed.
3. Drag the `.amxd` file into **User Library** in Live's Browser. You can also copy it to `Music/Ableton/User Library/MIDI Tools/Max Generators` inside your home folder.
4. Give Live a moment to index the file. If it does not appear immediately after startup, wait for the User Library scan to settle before copying it again.
5. Select a MIDI clip, open the clip's **Generate** panel, and choose **Rhythm Dice** from the User section.
6. Set Family, Seed, Bars, Density, Feel, Human, and Fill. Click the die to roll a new pattern, then click Live's Apply icon.

The Five Count family writes true five-beat bars. Set the clip time signature to 5/4 and its loop length to `5 × Bars` beats when using it.

## Controls

- **Family**: Random plus eight named rhythm families.
- **Seed**: deterministic pattern key.
- **Bars**: 1 to 4.
- **Density**: removes or adds optional events around each family's anchors.
- **Feel**: moves selected off-grid events.
- **Human**: deterministic timing and velocity variation.
- **Fill**: off, final bar, or every bar.
- **Die**: advances the seed and generates a new pattern.

Default drum pitches are kick 36, snare 38, clap/percussion 39, and closed hat 42.

## Build and test

```sh
npm test
npm run check
npm run validate
```

The build uses the accepted Max-saved container in `template/`, embeds the tested Max 9 V8 source, repairs the current patch metadata, and round-trip validates the emitted `.amxd`.

## License and authorship

MIT licensed. James Dishman directed the product and musical decisions. Clarence assisted with code, tests, packaging, and documentation under James's direction and review.
