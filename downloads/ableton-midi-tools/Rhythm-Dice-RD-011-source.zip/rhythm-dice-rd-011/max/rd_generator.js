/*
 * Rhythm Dice core for Ableton Live 12 MIDI Tools.
 *
 * This file is deliberately dependency-free and ES5-compatible so the same
 * source can run under Node's CommonJS loader and Max's JavaScript object.
 */
(function (root, factory) {
  if (typeof module !== 'undefined' && module.exports) module.exports = factory();
  else root.RhythmDice = factory();
}(this, function () {
  'use strict';

  var DRUM_NOTES = { kick: 36, snare: 38, perc: 39, hat: 42 };
  var FAMILY_KEYS = [
    'crooked-pocket', 'uk-swing', 'five-count-break', 'dirty-machine',
    'ghost-hardware', 'lo-fi-circuit', 'anchor-ghosts', 'found-object-skeleton'
  ];

  function ownKeys(object) {
    var result = [];
    var key;
    for (key in object) if (Object.prototype.hasOwnProperty.call(object, key)) result.push(key);
    return result;
  }

  function clamp(value, low, high) {
    var number = Number(value);
    if (!(number === number)) number = low;
    return Math.max(low, Math.min(high, number));
  }

  function integer(value, fallback) {
    var number = Number(value);
    if (!(number === number) || !isFinite(number)) return fallback;
    return Math.round(number);
  }

  function imul(a, b) {
    if (Math.imul) return Math.imul(a, b);
    var ah = (a >>> 16) & 65535;
    var al = a & 65535;
    return (al * b + (((ah * b) & 65535) << 16)) | 0;
  }

  function hashSeed(value) {
    var string = String(value);
    var hash = 2166136261;
    var index;
    for (index = 0; index < string.length; index += 1) {
      hash ^= string.charCodeAt(index);
      hash = imul(hash, 16777619);
    }
    return hash >>> 0;
  }

  function mulberry32(seed) {
    var state = seed >>> 0;
    return function () {
      var t;
      state = (state + 1831565813) | 0;
      t = imul(state ^ (state >>> 15), 1 | state);
      t = (t + imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  function makeRng(seed) {
    var parts = [String(seed)];
    var index;
    for (index = 1; index < arguments.length; index += 1) parts.push(String(arguments[index]));
    return mulberry32(hashSeed(parts.join('|')));
  }

  function pick(rng, values) {
    return values[Math.floor(rng() * values.length)];
  }

  function note(role, slot, velocity, offset) {
    return { role: role, slot: slot, velocity: velocity, offset: offset || 0 };
  }

  function samePosition(a, b) {
    return a.role === b.role && a.slot === b.slot;
  }

  function hasPosition(notes, role, slot) {
    var index;
    for (index = 0; index < notes.length; index += 1) {
      if (notes[index].role === role && notes[index].slot === slot) return true;
    }
    return false;
  }

  function slotsForMeter(meter) { return meter[0] * 4; }

  function crookedPocket(rng, slots, mode) {
    var notes = [], push, lean, beat;
    push = pick(rng, [[0, 8], [0, 10, 8], [0, 8, 14]]);
    for (beat = 0; beat < push.length; beat += 1) notes.push(note('kick', push[beat], 112));
    notes.push(note('snare', 4, 108), note('snare', 12, 108));
    if (rng() < 0.4) notes.push(note('snare', 14, 52));
    lean = pick(rng, [[0, 3], [0, 2], [0, 3, 8]]);
    for (beat = 0; beat < 4; beat += 1) {
      notes.push(note('hat', beat * 4 + lean[0], 84));
      if (rng() < 0.8) notes.push(note('hat', beat * 4 + lean[1 % lean.length], 64));
    }
    notes.push(note('perc', 6, 66));
    if (rng() < 0.5) notes.push(note('perc', 11, 60));
    if (mode === 'fill') shapeFill(notes, rng, slots, ['snare', 'perc'], 0.6, FAMILIES['crooked-pocket'].anchors);
    return notes;
  }

  function ukSwing(rng, slots, mode) {
    var notes = [note('kick', 0, 116)], s, island;
    if (rng() < 0.7) notes.push(note('kick', 10, 98));
    notes.push(note('snare', 4, 110), note('snare', 12, 114));
    for (s = 0; s < 16; s += 2) notes.push(note('hat', s, s % 4 === 0 ? 88 : 62));
    island = pick(rng, [[3, 6], [7, 10], [11, 14]]);
    notes.push(note('hat', island[0], 70, 0.18), note('hat', island[1], 70, 0.18));
    notes.push(note('perc', 15, 58));
    if (mode === 'fill') shapeFill(notes, rng, slots, ['snare'], 0.7, FAMILIES['uk-swing'].anchors);
    return notes;
  }

  function fiveCountBreak(rng, slots, mode) {
    var notes = [note('kick', 0, 118), note('snare', 8, 112)], s, answer;
    for (s = 0; s < slots; s += 2) notes.push(note('hat', s, s % 4 === 0 ? 86 : 60));
    answer = pick(rng, [[12, 16], [13, 18], [12, 17]]);
    notes.push(note('kick', answer[0], 100), note('snare', answer[1], 104));
    if (rng() < 0.5) notes.push(note('kick', 6, 92));
    notes.push(note('perc', 19, 62));
    if (mode === 'fill') shapeFill(notes, rng, slots, ['snare', 'kick'], 0.65, FAMILIES['five-count-break'].anchors);
    return notes;
  }

  function dirtyMachine(rng, slots, mode) {
    var notes = [], s;
    for (s = 0; s < 16; s += 4) notes.push(note('kick', s, 118));
    notes.push(note('snare', 4, 106), note('snare', 12, 106));
    for (s = 2; s < 16; s += 4) notes.push(note('hat', s, 92));
    notes.push(note('perc', 7, 70), note('perc', 13, 66));
    if (rng() < 0.5) notes.push(note('perc', 15, 74));
    if (mode === 'fill') shapeFill(notes, rng, slots, ['perc', 'snare'], 0.75, FAMILIES['dirty-machine'].anchors);
    return notes;
  }

  function ghostHardware(rng, slots, mode) {
    var notes = [note('kick', 0, 120)], s;
    if (rng() < 0.6) notes.push(note('kick', 11, 88, -0.15));
    notes.push(note('snare', 8, 110));
    for (s = 0; s < 4; s += 1) {
      var ghostSlots = [3, 6, 10, 14];
      if (rng() < 0.75) notes.push(note('snare', ghostSlots[s], 34));
    }
    for (s = 0; s < 16; s += 4) notes.push(note('hat', s, 76));
    notes.push(note('perc', 9, 54));
    if (mode === 'fill') shapeFill(notes, rng, slots, ['snare'], 0.55, FAMILIES['ghost-hardware'].anchors);
    return notes;
  }

  function loFiCircuit(rng, slots, mode) {
    var notes = [note('kick', 0, 116), note('kick', 10, 96, 0.12)], b;
    notes.push(note('snare', 8, 104));
    for (b = 0; b < 4; b += 1) {
      notes.push(note('hat', b * 4, 78));
      if (rng() < 0.85) notes.push(note('hat', b * 4 + 3, 56, 0.2));
    }
    notes.push(note('perc', 14, 50));
    if (mode === 'fill') shapeFill(notes, rng, slots, ['snare', 'perc'], 0.5, FAMILIES['lo-fi-circuit'].anchors);
    return notes;
  }

  function anchorGhosts(rng, slots, mode) {
    var notes = [note('kick', 0, 114), note('kick', 6, 100)], s;
    notes.push(note('snare', 4, 112), note('snare', 12, 112));
    for (s = 0; s < 4; s += 1) {
      var ghostSlots = [2, 7, 10, 15];
      if (rng() < 0.8) notes.push(note('snare', ghostSlots[s], 36));
    }
    for (s = 0; s < 16; s += 2) notes.push(note('hat', s, s % 4 === 0 ? 82 : 58));
    if (mode === 'fill') shapeFill(notes, rng, slots, ['snare'], 0.6, FAMILIES['anchor-ghosts'].anchors);
    return notes;
  }

  function foundObjectSkeleton(rng, slots, mode) {
    var notes = [note('kick', 0, 112)], s;
    if (rng() < 0.6) notes.push(note('kick', 7, 90));
    notes.push(note('snare', 8, 106), note('perc', 2, 72), note('perc', 5, 58), note('perc', 11, 66));
    if (rng() < 0.6) notes.push(note('perc', 14, 62));
    for (s = 0; s < 16; s += 8) notes.push(note('hat', s, 70));
    if (mode === 'fill') shapeFill(notes, rng, slots, ['perc'], 0.7, FAMILIES['found-object-skeleton'].anchors);
    return notes;
  }

  var FAMILIES = {
    'crooked-pocket': { name: 'Crooked Pocket', meter: [4, 4], anchors: { kick: [0, 8], snare: [4, 12] }, generate: crookedPocket },
    'uk-swing': { name: 'UK Swing', meter: [4, 4], anchors: { kick: [0], snare: [4, 12] }, generate: ukSwing },
    'five-count-break': { name: 'Five-Count Break', meter: [5, 4], anchors: { kick: [0], snare: [8] }, generate: fiveCountBreak },
    'dirty-machine': { name: 'Dirty Machine', meter: [4, 4], anchors: { kick: [0, 4, 8, 12], snare: [4, 12] }, generate: dirtyMachine },
    'ghost-hardware': { name: 'Ghost Hardware', meter: [4, 4], anchors: { kick: [0], snare: [8] }, generate: ghostHardware },
    'lo-fi-circuit': { name: 'Lo-fi Circuit', meter: [4, 4], anchors: { kick: [0, 10], snare: [8] }, generate: loFiCircuit },
    'anchor-ghosts': { name: 'Anchor + Ghosts', meter: [4, 4], anchors: { kick: [0, 6], snare: [4, 12] }, generate: anchorGhosts },
    'found-object-skeleton': { name: 'Found-object Skeleton', meter: [4, 4], anchors: { kick: [0], snare: [8] }, generate: foundObjectSkeleton }
  };

  var DENSITY_CANDIDATES = {
    'crooked-pocket': [['hat', 1], ['hat', 5], ['hat', 9], ['hat', 13], ['perc', 3], ['perc', 10], ['snare', 15]],
    'uk-swing': [['hat', 1], ['hat', 5], ['hat', 9], ['hat', 13], ['perc', 6], ['perc', 14], ['kick', 15]],
    'five-count-break': [['hat', 1], ['hat', 5], ['hat', 9], ['hat', 13], ['hat', 17], ['kick', 14], ['snare', 19]],
    'dirty-machine': [['hat', 0], ['hat', 4], ['hat', 8], ['hat', 12], ['perc', 3], ['perc', 11], ['perc', 15]],
    'ghost-hardware': [['snare', 1], ['snare', 5], ['snare', 13], ['hat', 2], ['hat', 6], ['perc', 12]],
    'lo-fi-circuit': [['hat', 1], ['hat', 5], ['hat', 9], ['hat', 13], ['perc', 7], ['perc', 15]],
    'anchor-ghosts': [['snare', 1], ['snare', 6], ['snare', 11], ['snare', 15], ['perc', 3], ['perc', 14]],
    'found-object-skeleton': [['perc', 0], ['perc', 7], ['perc', 9], ['perc', 15], ['hat', 4], ['hat', 12]]
  };

  var SEED_MOTIFS = {
    'crooked-pocket': [[['hat', 1], ['hat', 6], ['perc', 10]], [['hat', 2], ['hat', 7], ['perc', 13]], [['hat', 1], ['hat', 5], ['snare', 15]], [['hat', 3], ['hat', 6], ['perc', 11]]],
    'uk-swing': [[['hat', 3], ['hat', 7], ['perc', 11]], [['hat', 1], ['hat', 6], ['perc', 14]], [['hat', 5], ['hat', 10], ['kick', 15]], [['hat', 3], ['hat', 11], ['perc', 15]]],
    'five-count-break': [[['kick', 6], ['hat', 7], ['snare', 14]], [['kick', 10], ['hat', 11], ['snare', 17]], [['kick', 13], ['hat', 15], ['perc', 18]], [['snare', 5], ['hat', 9], ['kick', 16]]],
    'dirty-machine': [[['perc', 3], ['perc', 7], ['hat', 14]], [['perc', 1], ['perc', 9], ['hat', 6]], [['perc', 5], ['perc', 11], ['hat', 10]], [['perc', 3], ['perc', 13], ['snare', 15]]],
    'ghost-hardware': [[['snare', 2], ['snare', 6], ['perc', 13]], [['snare', 3], ['snare', 10], ['hat', 7]], [['snare', 5], ['snare', 12], ['perc', 15]], [['snare', 1], ['snare', 9], ['hat', 14]]],
    'lo-fi-circuit': [[['hat', 1], ['hat', 6], ['perc', 13]], [['hat', 3], ['hat', 7], ['perc', 15]], [['hat', 5], ['hat', 10], ['perc', 12]], [['hat', 1], ['hat', 9], ['snare', 15]]],
    'anchor-ghosts': [[['snare', 1], ['snare', 6], ['perc', 13]], [['snare', 3], ['snare', 9], ['perc', 15]], [['snare', 5], ['snare', 11], ['hat', 13]], [['snare', 2], ['snare', 7], ['perc', 14]]],
    'found-object-skeleton': [[['perc', 1], ['perc', 7], ['hat', 13]], [['perc', 3], ['perc', 9], ['perc', 15]], [['perc', 4], ['perc', 12], ['kick', 14]], [['perc', 6], ['perc', 11], ['hat', 15]]]
  };

  var MOTIF_LANES = {
    'crooked-pocket': ['hat', 'hat', 'perc', 'hat'], 'uk-swing': ['hat', 'hat', 'perc', 'kick'],
    'five-count-break': ['kick', 'hat', 'snare', 'perc'], 'dirty-machine': ['perc', 'perc', 'hat', 'perc'],
    'ghost-hardware': ['snare', 'snare', 'hat', 'perc'], 'lo-fi-circuit': ['hat', 'hat', 'perc', 'snare'],
    'anchor-ghosts': ['snare', 'snare', 'perc', 'hat'], 'found-object-skeleton': ['perc', 'perc', 'hat', 'kick']
  };

  function addSeedMotif(notes, family, slots, rng) {
    var motifs = SEED_MOTIFS[family], motif, index, role, slot, phase, phaseTwo, distance, lanes;
    if (!motifs) return;
    motif = pick(rng, motifs);
    for (index = 0; index < motif.length; index += 1) {
      role = motif[index][0]; slot = motif[index][1] % slots;
      if (!hasPosition(notes, role, slot)) notes.push(note(role, slot, 48 + index * 12, index === 1 ? 0.08 : 0));
    }
    lanes = MOTIF_LANES[family] || ['hat', 'hat', 'perc', 'perc'];
    phase = Math.floor(rng() * slots);
    for (index = 0; index < 4; index += 1) {
      distance = [1, 4, 7, 10][index]; role = lanes[index]; slot = (phase + distance) % slots;
      if (!hasPosition(notes, role, slot)) notes.push(note(role, slot, 40 + index * 9, index % 2 ? -0.06 : 0.04));
    }
    phaseTwo = Math.floor(rng() * slots);
    for (index = 0; index < 5; index += 1) {
      distance = [0, 3, 6, 9, 12][index]; role = lanes[(index + 1) % lanes.length]; slot = (phaseTwo + distance) % slots;
      if (!hasPosition(notes, role, slot)) notes.push(note(role, slot, 52 + index * 6, 0));
    }
  }

  function shapeFill(notes, rng, slots, roles, intensity, anchors) {
    var phraseStart = Math.max(0, slots - 8), retained = [], index, item, isStrong, useHalf, length, start, patterns, pattern, occupancy, roleIndex, progress, velocity, role, duplicate, lastSlot, final;
    for (index = 0; index < notes.length; index += 1) {
      item = notes[index]; isStrong = false;
      if (item.slot >= phraseStart && anchors[item.role]) {
        isStrong = anchors[item.role].indexOf(item.slot) !== -1;
      }
      if (item.slot < phraseStart || isStrong) retained.push(item);
    }
    notes.splice(0, notes.length);
    for (index = 0; index < retained.length; index += 1) notes.push(retained[index]);
    useHalf = rng() < Math.max(0.1, intensity - 0.45);
    length = useHalf ? 8 : 4; start = slots - length;
    patterns = length === 4 ? [[0, 2, 3], [0, 1, 3], [1, 2, 3]] : [[0, 2, 3, 4, 6, 7], [0, 2, 4, 5, 7], [0, 1, 3, 4, 6, 7]];
    pattern = pick(rng, patterns);
    for (index = 0; index < pattern.length; index += 1) {
      item = start + pattern[index]; occupancy = 0;
      for (roleIndex = 0; roleIndex < notes.length; roleIndex += 1) if (notes[roleIndex].slot === item) occupancy += 1;
      if (occupancy >= 2 && item !== slots - 1) continue;
      roleIndex = Math.min(roles.length - 1, Math.floor(index * roles.length / pattern.length));
      role = roles[roleIndex]; progress = pattern.length === 1 ? 1 : index / (pattern.length - 1);
      velocity = item === slots - 1 ? 120 : Math.round(68 + progress * 32);
      duplicate = hasPosition(notes, role, item);
      if (!duplicate) notes.push(note(role, item, velocity));
    }
    lastSlot = slots - 1; final = null;
    for (index = 0; index < notes.length; index += 1) if (notes[index].slot === lastSlot) { final = notes[index]; break; }
    if (final) final.velocity = Math.max(final.velocity, 114);
    else notes.push(note(roles[roles.length - 1], lastSlot, 114));
  }

  function densityCandidates(family, slots, rng) {
    var source = DENSITY_CANDIDATES[family] || [['hat', 1], ['hat', 5], ['perc', 7], ['perc', 15]], shift, result = [], index, item;
    shift = Math.floor(rng() * Math.max(1, Math.min(4, slots / 8))) * 2;
    for (index = 0; index < source.length; index += 1) {
      item = source[index];
      result.push(note(item[0], (item[1] + (index % 2 ? shift : 0)) % slots, 44 + ((index * 7) % 25), 0));
    }
    return result;
  }

  function positionKey(item) { return item.role + ':' + item.slot; }

  function applyDensity(family, notes, density, rng, slots) {
    var fam = FAMILIES[family], anchors = {}, optional = [], candidates, amount, target, result, index, item, dropCount, sorted, dropped;
    var i;
    for (i = 0; i < ownKeys(fam.anchors).length; i += 1) {
      var role = ownKeys(fam.anchors)[i], anchorList = fam.anchors[role], j;
      for (j = 0; j < anchorList.length; j += 1) anchors[role + ':' + anchorList[j]] = true;
    }
    for (i = 0; i < notes.length; i += 1) {
      if (!anchors[positionKey(notes[i])]) optional.push(notes[i]);
    }
    candidates = densityCandidates(family, slots, rng);
    amount = clamp(density, 0, 100) / 100;
    target = Math.round((optional.length + candidates.length) * (0.15 + amount * 0.95));
    result = notes.slice();
    if (optional.length > target) {
      dropCount = optional.length - target; sorted = optional.slice().sort(function (a, b) { return a.velocity - b.velocity || a.slot - b.slot; });
      dropped = {};
      for (i = 0; i < dropCount; i += 1) dropped[positionKey(sorted[i])] = true;
      result = [];
      for (i = 0; i < notes.length; i += 1) if (anchors[positionKey(notes[i])] || !dropped[positionKey(notes[i])]) result.push(notes[i]);
      return result;
    }
    if (optional.length < target && amount > 0.35) {
      for (i = 0; i < candidates.length; i += 1) {
        item = candidates[i];
        if (result.filter(function (x) { return !anchors[positionKey(x)]; }).length >= target) break;
        if (!hasPosition(result, item.role, item.slot)) result.push(item);
      }
    }
    return result;
  }

  function applyFeel(notes, feel) {
    var amount = (clamp(feel, 0, 100) / 100 - 0.5) * 0.5, index, item;
    for (index = 0; index < notes.length; index += 1) {
      item = notes[index];
      if ((item.role === 'hat' || item.role === 'perc') && item.slot % 2 === 1) item.offset = clamp(item.offset + amount, -0.5, 0.5);
    }
  }

  function humanize(notes, amount, rng) {
    var scale = clamp(amount, 0, 100) / 100, index, item;
    for (index = 0; index < notes.length; index += 1) {
      item = notes[index];
      item.offset = clamp(item.offset + (rng() * 2 - 1) * 0.3 * scale, -0.5, 0.5);
      item.velocity = clamp(item.velocity + Math.round((rng() - 0.5) * 30 * scale), 1, 127);
    }
  }

  function normalizeSettings(settings) {
    var source = settings || {}, bars = integer(source.bars, 2), family = source.family || 'random', fill = source.fill || 'off';
    if (FAMILY_KEYS.indexOf(family) === -1) family = 'random';
    if (fill !== 'last' && fill !== 'every') fill = 'off';
    return {
      family: family, seed: source.seed === undefined ? 'rhythm-dice' : String(source.seed),
      bars: Math.max(1, Math.min(4, bars)), density: clamp(source.density === undefined ? 50 : source.density, 0, 100),
      feel: clamp(source.feel === undefined ? 50 : source.feel, 0, 100), humanize: clamp(source.humanize === undefined ? 30 : source.humanize, 0, 100), fill: fill
    };
  }

  function roundTime(value) { return Math.round(value * 1000000) / 1000000; }

  function toMidiNote(item, barStart, totalBeats) {
    var duration = 0.2, maxStart = Math.max(0, totalBeats - duration), start = clamp(barStart + item.slot * 0.25 + item.offset * 0.25, 0, maxStart);
    return {
      pitch: DRUM_NOTES[item.role], start_time: roundTime(start), duration: duration,
      velocity: Math.round(clamp(item.velocity, 1, 127)), mute: false, probability: 1,
      velocity_deviation: 0, release_velocity: 64
    };
  }

  function generatePattern(settings) {
    var config = normalizeSettings(settings), familyRng = makeRng(config.seed, 'family'), family = config.family === 'random' ? pick(familyRng, FAMILY_KEYS) : config.family;
    var fam = FAMILIES[family], meter = [fam.meter[0], fam.meter[1]], beatsPerBar = meter[0] * (4 / meter[1]), totalBeats = config.bars * beatsPerBar;
    var fillBars = [], barStarts = [], notes = [], bar, slots, mode, generated, processed, index, barStart;
    for (bar = 0; bar < config.bars; bar += 1) {
      barStarts.push(bar * beatsPerBar);
      mode = (config.fill === 'every' || (config.fill === 'last' && bar === config.bars - 1)) ? 'fill' : 'groove';
      if (mode === 'fill') fillBars.push(bar);
      slots = slotsForMeter(meter);
      generated = fam.generate(makeRng(config.seed, family, mode, bar, meter.join('/')), slots, mode);
      if (mode !== 'fill') addSeedMotif(generated, family, slots, makeRng(config.seed, 'motif', family, bar, meter.join('/')));
      processed = applyDensity(family, generated, config.density, makeRng(config.seed, 'density', bar), slots);
      applyFeel(processed, config.feel);
      humanize(processed, config.humanize, makeRng(config.seed, 'humanize', bar));
      barStart = barStarts[bar];
      for (index = 0; index < processed.length; index += 1) notes.push(toMidiNote(processed[index], barStart, totalBeats));
    }
    notes.sort(function (a, b) { return a.start_time - b.start_time || a.pitch - b.pitch || a.velocity - b.velocity; });
    return { notes: notes, family: family, meter: meter, bars: config.bars, totalBeats: totalBeats, barStarts: barStarts, fillBars: fillBars, settings: config };
  }

  function generate(settings) { return { notes: generatePattern(settings).notes }; }

  function advanceSeed(seed) { return hashSeed(String(seed) + '|roll').toString(36); }

  return {
    DRUM_NOTES: DRUM_NOTES,
    FAMILY_KEYS: FAMILY_KEYS,
    FAMILIES: FAMILIES,
    hashSeed: hashSeed,
    makeRng: makeRng,
    normalizeSettings: normalizeSettings,
    generate: generate,
    generatePattern: generatePattern,
    advanceSeed: advanceSeed,
    slotsForMeter: slotsForMeter
  };
}));

/* Max wrapper appended to the portable core by the bundle build. */
autowatch = 1;
inlets = 2;
outlets = 1;

var rdSettings = {
  family: 'random', seed: 'rhythm-dice', bars: 2,
  density: 50, feel: 50, humanize: 30, fill: 'off'
};
var rdCore = (typeof RhythmDice !== 'undefined') ? RhythmDice : ((typeof module !== 'undefined') ? module.exports : null);

function rdOutput() {
  outlet_dictionary(0, rdCore.generate(rdSettings));
}

/* Max 9 v8 converts the incoming MIDI Tool Dict to a native JS object. */
function msg_dictionary(value) { rdOutput(); }
function bang() { rdOutput(); }

function family(value) { rdSettings.family = value === undefined ? 'random' : String(value); }
function family_index(value) { rdSettings.family = rdFamilyFromIndex(value); }
function seed(value) { if (value !== undefined) rdSettings.seed = String(value); }
function bars(value) { if (value !== undefined) rdSettings.bars = Number(value); }
function bars_index(value) { rdSettings.bars = Number(value) + 1; }
function density(value) { rdSettings.density = value; }
function feel(value) { rdSettings.feel = value; }
function humanize(value) { rdSettings.humanize = value; }
function fill(value) { rdSettings.fill = String(value); }
function fill_index(value) { rdSettings.fill = rdFillFromIndex(value); }
function roll() { rdSettings.seed = rdCore.advanceSeed(rdSettings.seed); }
function apply() { roll(); }

function rdFamilyFromIndex(index) {
  var i = Math.max(0, Math.min(rdCore.FAMILY_KEYS.length, Math.round(Number(index) || 0)));
  return i === 0 ? 'random' : rdCore.FAMILY_KEYS[i - 1];
}
function rdFillFromIndex(index) {
  var i = Math.round(Number(index) || 0);
  return i === 1 ? 'last' : (i === 2 ? 'every' : 'off');
}
