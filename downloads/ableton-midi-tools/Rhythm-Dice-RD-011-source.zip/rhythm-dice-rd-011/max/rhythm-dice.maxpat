{
  "patcher": {
    "fileversion": 1,
    "appversion": {
      "major": 8,
      "minor": 6,
      "revision": 2,
      "architecture": "x64",
      "modernui": 1
    },
    "classnamespace": "box",
    "rect": [
      0.0,
      0.0,
      900.0,
      560.0
    ],
    "bglocked": 0,
    "openinpresentation": 1,
    "default_fontsize": 12.0,
    "default_fontface": 0,
    "default_fontname": "Arial",
    "devicewidth": 150.0,
    "boxes": [
      {
        "box": {
          "id": "in",
          "maxclass": "newobj",
          "text": "live.miditool.in",
          "patching_rect": [
            40.0,
            350.0,
            105.0,
            22.0
          ]
        }
      },
      {
        "box": {
          "id": "generator",
          "maxclass": "newobj",
          "text": "v8",
          "numinlets": 2,
          "numoutlets": 1,
          "outlettype": [
            "dictionary"
          ],
          "patching_rect": [
            220.0,
            350.0,
            130.0,
            22.0
          ],
          "saved_object_attributes": {
            "parameter_enable": 0
          },
          "filename": "none",
          "textfile": {
            "text": "/*\n * Rhythm Dice core for Ableton Live 12 MIDI Tools.\n *\n * This file is deliberately dependency-free and ES5-compatible so the same\n * source can run under Node's CommonJS loader and Max's JavaScript object.\n */\n(function (root, factory) {\n  if (typeof module !== 'undefined' && module.exports) module.exports = factory();\n  else root.RhythmDice = factory();\n}(this, function () {\n  'use strict';\n\n  var DRUM_NOTES = { kick: 36, snare: 38, perc: 39, hat: 42 };\n  var FAMILY_KEYS = [\n    'crooked-pocket', 'uk-swing', 'five-count-break', 'dirty-machine',\n    'ghost-hardware', 'lo-fi-circuit', 'anchor-ghosts', 'found-object-skeleton'\n  ];\n\n  function ownKeys(object) {\n    var result = [];\n    var key;\n    for (key in object) if (Object.prototype.hasOwnProperty.call(object, key)) result.push(key);\n    return result;\n  }\n\n  function clamp(value, low, high) {\n    var number = Number(value);\n    if (!(number === number)) number = low;\n    return Math.max(low, Math.min(high, number));\n  }\n\n  function integer(value, fallback) {\n    var number = Number(value);\n    if (!(number === number) || !isFinite(number)) return fallback;\n    return Math.round(number);\n  }\n\n  function imul(a, b) {\n    if (Math.imul) return Math.imul(a, b);\n    var ah = (a >>> 16) & 65535;\n    var al = a & 65535;\n    return (al * b + (((ah * b) & 65535) << 16)) | 0;\n  }\n\n  function hashSeed(value) {\n    var string = String(value);\n    var hash = 2166136261;\n    var index;\n    for (index = 0; index < string.length; index += 1) {\n      hash ^= string.charCodeAt(index);\n      hash = imul(hash, 16777619);\n    }\n    return hash >>> 0;\n  }\n\n  function mulberry32(seed) {\n    var state = seed >>> 0;\n    return function () {\n      var t;\n      state = (state + 1831565813) | 0;\n      t = imul(state ^ (state >>> 15), 1 | state);\n      t = (t + imul(t ^ (t >>> 7), 61 | t)) ^ t;\n      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;\n    };\n  }\n\n  function makeRng(seed) {\n    var parts = [String(seed)];\n    var index;\n    for (index = 1; index < arguments.length; index += 1) parts.push(String(arguments[index]));\n    return mulberry32(hashSeed(parts.join('|')));\n  }\n\n  function pick(rng, values) {\n    return values[Math.floor(rng() * values.length)];\n  }\n\n  function note(role, slot, velocity, offset) {\n    return { role: role, slot: slot, velocity: velocity, offset: offset || 0 };\n  }\n\n  function samePosition(a, b) {\n    return a.role === b.role && a.slot === b.slot;\n  }\n\n  function hasPosition(notes, role, slot) {\n    var index;\n    for (index = 0; index < notes.length; index += 1) {\n      if (notes[index].role === role && notes[index].slot === slot) return true;\n    }\n    return false;\n  }\n\n  function slotsForMeter(meter) { return meter[0] * 4; }\n\n  function crookedPocket(rng, slots, mode) {\n    var notes = [], push, lean, beat;\n    push = pick(rng, [[0, 8], [0, 10, 8], [0, 8, 14]]);\n    for (beat = 0; beat < push.length; beat += 1) notes.push(note('kick', push[beat], 112));\n    notes.push(note('snare', 4, 108), note('snare', 12, 108));\n    if (rng() < 0.4) notes.push(note('snare', 14, 52));\n    lean = pick(rng, [[0, 3], [0, 2], [0, 3, 8]]);\n    for (beat = 0; beat < 4; beat += 1) {\n      notes.push(note('hat', beat * 4 + lean[0], 84));\n      if (rng() < 0.8) notes.push(note('hat', beat * 4 + lean[1 % lean.length], 64));\n    }\n    notes.push(note('perc', 6, 66));\n    if (rng() < 0.5) notes.push(note('perc', 11, 60));\n    if (mode === 'fill') shapeFill(notes, rng, slots, ['snare', 'perc'], 0.6, FAMILIES['crooked-pocket'].anchors);\n    return notes;\n  }\n\n  function ukSwing(rng, slots, mode) {\n    var notes = [note('kick', 0, 116)], s, island;\n    if (rng() < 0.7) notes.push(note('kick', 10, 98));\n    notes.push(note('snare', 4, 110), note('snare', 12, 114));\n    for (s = 0; s < 16; s += 2) notes.push(note('hat', s, s % 4 === 0 ? 88 : 62));\n    island = pick(rng, [[3, 6], [7, 10], [11, 14]]);\n    notes.push(note('hat', island[0], 70, 0.18), note('hat', island[1], 70, 0.18));\n    notes.push(note('perc', 15, 58));\n    if (mode === 'fill') shapeFill(notes, rng, slots, ['snare'], 0.7, FAMILIES['uk-swing'].anchors);\n    return notes;\n  }\n\n  function fiveCountBreak(rng, slots, mode) {\n    var notes = [note('kick', 0, 118), note('snare', 8, 112)], s, answer;\n    for (s = 0; s < slots; s += 2) notes.push(note('hat', s, s % 4 === 0 ? 86 : 60));\n    answer = pick(rng, [[12, 16], [13, 18], [12, 17]]);\n    notes.push(note('kick', answer[0], 100), note('snare', answer[1], 104));\n    if (rng() < 0.5) notes.push(note('kick', 6, 92));\n    notes.push(note('perc', 19, 62));\n    if (mode === 'fill') shapeFill(notes, rng, slots, ['snare', 'kick'], 0.65, FAMILIES['five-count-break'].anchors);\n    return notes;\n  }\n\n  function dirtyMachine(rng, slots, mode) {\n    var notes = [], s;\n    for (s = 0; s < 16; s += 4) notes.push(note('kick', s, 118));\n    notes.push(note('snare', 4, 106), note('snare', 12, 106));\n    for (s = 2; s < 16; s += 4) notes.push(note('hat', s, 92));\n    notes.push(note('perc', 7, 70), note('perc', 13, 66));\n    if (rng() < 0.5) notes.push(note('perc', 15, 74));\n    if (mode === 'fill') shapeFill(notes, rng, slots, ['perc', 'snare'], 0.75, FAMILIES['dirty-machine'].anchors);\n    return notes;\n  }\n\n  function ghostHardware(rng, slots, mode) {\n    var notes = [note('kick', 0, 120)], s;\n    if (rng() < 0.6) notes.push(note('kick', 11, 88, -0.15));\n    notes.push(note('snare', 8, 110));\n    for (s = 0; s < 4; s += 1) {\n      var ghostSlots = [3, 6, 10, 14];\n      if (rng() < 0.75) notes.push(note('snare', ghostSlots[s], 34));\n    }\n    for (s = 0; s < 16; s += 4) notes.push(note('hat', s, 76));\n    notes.push(note('perc', 9, 54));\n    if (mode === 'fill') shapeFill(notes, rng, slots, ['snare'], 0.55, FAMILIES['ghost-hardware'].anchors);\n    return notes;\n  }\n\n  function loFiCircuit(rng, slots, mode) {\n    var notes = [note('kick', 0, 116), note('kick', 10, 96, 0.12)], b;\n    notes.push(note('snare', 8, 104));\n    for (b = 0; b < 4; b += 1) {\n      notes.push(note('hat', b * 4, 78));\n      if (rng() < 0.85) notes.push(note('hat', b * 4 + 3, 56, 0.2));\n    }\n    notes.push(note('perc', 14, 50));\n    if (mode === 'fill') shapeFill(notes, rng, slots, ['snare', 'perc'], 0.5, FAMILIES['lo-fi-circuit'].anchors);\n    return notes;\n  }\n\n  function anchorGhosts(rng, slots, mode) {\n    var notes = [note('kick', 0, 114), note('kick', 6, 100)], s;\n    notes.push(note('snare', 4, 112), note('snare', 12, 112));\n    for (s = 0; s < 4; s += 1) {\n      var ghostSlots = [2, 7, 10, 15];\n      if (rng() < 0.8) notes.push(note('snare', ghostSlots[s], 36));\n    }\n    for (s = 0; s < 16; s += 2) notes.push(note('hat', s, s % 4 === 0 ? 82 : 58));\n    if (mode === 'fill') shapeFill(notes, rng, slots, ['snare'], 0.6, FAMILIES['anchor-ghosts'].anchors);\n    return notes;\n  }\n\n  function foundObjectSkeleton(rng, slots, mode) {\n    var notes = [note('kick', 0, 112)], s;\n    if (rng() < 0.6) notes.push(note('kick', 7, 90));\n    notes.push(note('snare', 8, 106), note('perc', 2, 72), note('perc', 5, 58), note('perc', 11, 66));\n    if (rng() < 0.6) notes.push(note('perc', 14, 62));\n    for (s = 0; s < 16; s += 8) notes.push(note('hat', s, 70));\n    if (mode === 'fill') shapeFill(notes, rng, slots, ['perc'], 0.7, FAMILIES['found-object-skeleton'].anchors);\n    return notes;\n  }\n\n  var FAMILIES = {\n    'crooked-pocket': { name: 'Crooked Pocket', meter: [4, 4], anchors: { kick: [0, 8], snare: [4, 12] }, generate: crookedPocket },\n    'uk-swing': { name: 'UK Swing', meter: [4, 4], anchors: { kick: [0], snare: [4, 12] }, generate: ukSwing },\n    'five-count-break': { name: 'Five-Count Break', meter: [5, 4], anchors: { kick: [0], snare: [8] }, generate: fiveCountBreak },\n    'dirty-machine': { name: 'Dirty Machine', meter: [4, 4], anchors: { kick: [0, 4, 8, 12], snare: [4, 12] }, generate: dirtyMachine },\n    'ghost-hardware': { name: 'Ghost Hardware', meter: [4, 4], anchors: { kick: [0], snare: [8] }, generate: ghostHardware },\n    'lo-fi-circuit': { name: 'Lo-fi Circuit', meter: [4, 4], anchors: { kick: [0, 10], snare: [8] }, generate: loFiCircuit },\n    'anchor-ghosts': { name: 'Anchor + Ghosts', meter: [4, 4], anchors: { kick: [0, 6], snare: [4, 12] }, generate: anchorGhosts },\n    'found-object-skeleton': { name: 'Found-object Skeleton', meter: [4, 4], anchors: { kick: [0], snare: [8] }, generate: foundObjectSkeleton }\n  };\n\n  var DENSITY_CANDIDATES = {\n    'crooked-pocket': [['hat', 1], ['hat', 5], ['hat', 9], ['hat', 13], ['perc', 3], ['perc', 10], ['snare', 15]],\n    'uk-swing': [['hat', 1], ['hat', 5], ['hat', 9], ['hat', 13], ['perc', 6], ['perc', 14], ['kick', 15]],\n    'five-count-break': [['hat', 1], ['hat', 5], ['hat', 9], ['hat', 13], ['hat', 17], ['kick', 14], ['snare', 19]],\n    'dirty-machine': [['hat', 0], ['hat', 4], ['hat', 8], ['hat', 12], ['perc', 3], ['perc', 11], ['perc', 15]],\n    'ghost-hardware': [['snare', 1], ['snare', 5], ['snare', 13], ['hat', 2], ['hat', 6], ['perc', 12]],\n    'lo-fi-circuit': [['hat', 1], ['hat', 5], ['hat', 9], ['hat', 13], ['perc', 7], ['perc', 15]],\n    'anchor-ghosts': [['snare', 1], ['snare', 6], ['snare', 11], ['snare', 15], ['perc', 3], ['perc', 14]],\n    'found-object-skeleton': [['perc', 0], ['perc', 7], ['perc', 9], ['perc', 15], ['hat', 4], ['hat', 12]]\n  };\n\n  var SEED_MOTIFS = {\n    'crooked-pocket': [[['hat', 1], ['hat', 6], ['perc', 10]], [['hat', 2], ['hat', 7], ['perc', 13]], [['hat', 1], ['hat', 5], ['snare', 15]], [['hat', 3], ['hat', 6], ['perc', 11]]],\n    'uk-swing': [[['hat', 3], ['hat', 7], ['perc', 11]], [['hat', 1], ['hat', 6], ['perc', 14]], [['hat', 5], ['hat', 10], ['kick', 15]], [['hat', 3], ['hat', 11], ['perc', 15]]],\n    'five-count-break': [[['kick', 6], ['hat', 7], ['snare', 14]], [['kick', 10], ['hat', 11], ['snare', 17]], [['kick', 13], ['hat', 15], ['perc', 18]], [['snare', 5], ['hat', 9], ['kick', 16]]],\n    'dirty-machine': [[['perc', 3], ['perc', 7], ['hat', 14]], [['perc', 1], ['perc', 9], ['hat', 6]], [['perc', 5], ['perc', 11], ['hat', 10]], [['perc', 3], ['perc', 13], ['snare', 15]]],\n    'ghost-hardware': [[['snare', 2], ['snare', 6], ['perc', 13]], [['snare', 3], ['snare', 10], ['hat', 7]], [['snare', 5], ['snare', 12], ['perc', 15]], [['snare', 1], ['snare', 9], ['hat', 14]]],\n    'lo-fi-circuit': [[['hat', 1], ['hat', 6], ['perc', 13]], [['hat', 3], ['hat', 7], ['perc', 15]], [['hat', 5], ['hat', 10], ['perc', 12]], [['hat', 1], ['hat', 9], ['snare', 15]]],\n    'anchor-ghosts': [[['snare', 1], ['snare', 6], ['perc', 13]], [['snare', 3], ['snare', 9], ['perc', 15]], [['snare', 5], ['snare', 11], ['hat', 13]], [['snare', 2], ['snare', 7], ['perc', 14]]],\n    'found-object-skeleton': [[['perc', 1], ['perc', 7], ['hat', 13]], [['perc', 3], ['perc', 9], ['perc', 15]], [['perc', 4], ['perc', 12], ['kick', 14]], [['perc', 6], ['perc', 11], ['hat', 15]]]\n  };\n\n  var MOTIF_LANES = {\n    'crooked-pocket': ['hat', 'hat', 'perc', 'hat'], 'uk-swing': ['hat', 'hat', 'perc', 'kick'],\n    'five-count-break': ['kick', 'hat', 'snare', 'perc'], 'dirty-machine': ['perc', 'perc', 'hat', 'perc'],\n    'ghost-hardware': ['snare', 'snare', 'hat', 'perc'], 'lo-fi-circuit': ['hat', 'hat', 'perc', 'snare'],\n    'anchor-ghosts': ['snare', 'snare', 'perc', 'hat'], 'found-object-skeleton': ['perc', 'perc', 'hat', 'kick']\n  };\n\n  function addSeedMotif(notes, family, slots, rng) {\n    var motifs = SEED_MOTIFS[family], motif, index, role, slot, phase, phaseTwo, distance, lanes;\n    if (!motifs) return;\n    motif = pick(rng, motifs);\n    for (index = 0; index < motif.length; index += 1) {\n      role = motif[index][0]; slot = motif[index][1] % slots;\n      if (!hasPosition(notes, role, slot)) notes.push(note(role, slot, 48 + index * 12, index === 1 ? 0.08 : 0));\n    }\n    lanes = MOTIF_LANES[family] || ['hat', 'hat', 'perc', 'perc'];\n    phase = Math.floor(rng() * slots);\n    for (index = 0; index < 4; index += 1) {\n      distance = [1, 4, 7, 10][index]; role = lanes[index]; slot = (phase + distance) % slots;\n      if (!hasPosition(notes, role, slot)) notes.push(note(role, slot, 40 + index * 9, index % 2 ? -0.06 : 0.04));\n    }\n    phaseTwo = Math.floor(rng() * slots);\n    for (index = 0; index < 5; index += 1) {\n      distance = [0, 3, 6, 9, 12][index]; role = lanes[(index + 1) % lanes.length]; slot = (phaseTwo + distance) % slots;\n      if (!hasPosition(notes, role, slot)) notes.push(note(role, slot, 52 + index * 6, 0));\n    }\n  }\n\n  function shapeFill(notes, rng, slots, roles, intensity, anchors) {\n    var phraseStart = Math.max(0, slots - 8), retained = [], index, item, isStrong, useHalf, length, start, patterns, pattern, occupancy, roleIndex, progress, velocity, role, duplicate, lastSlot, final;\n    for (index = 0; index < notes.length; index += 1) {\n      item = notes[index]; isStrong = false;\n      if (item.slot >= phraseStart && anchors[item.role]) {\n        isStrong = anchors[item.role].indexOf(item.slot) !== -1;\n      }\n      if (item.slot < phraseStart || isStrong) retained.push(item);\n    }\n    notes.splice(0, notes.length);\n    for (index = 0; index < retained.length; index += 1) notes.push(retained[index]);\n    useHalf = rng() < Math.max(0.1, intensity - 0.45);\n    length = useHalf ? 8 : 4; start = slots - length;\n    patterns = length === 4 ? [[0, 2, 3], [0, 1, 3], [1, 2, 3]] : [[0, 2, 3, 4, 6, 7], [0, 2, 4, 5, 7], [0, 1, 3, 4, 6, 7]];\n    pattern = pick(rng, patterns);\n    for (index = 0; index < pattern.length; index += 1) {\n      item = start + pattern[index]; occupancy = 0;\n      for (roleIndex = 0; roleIndex < notes.length; roleIndex += 1) if (notes[roleIndex].slot === item) occupancy += 1;\n      if (occupancy >= 2 && item !== slots - 1) continue;\n      roleIndex = Math.min(roles.length - 1, Math.floor(index * roles.length / pattern.length));\n      role = roles[roleIndex]; progress = pattern.length === 1 ? 1 : index / (pattern.length - 1);\n      velocity = item === slots - 1 ? 120 : Math.round(68 + progress * 32);\n      duplicate = hasPosition(notes, role, item);\n      if (!duplicate) notes.push(note(role, item, velocity));\n    }\n    lastSlot = slots - 1; final = null;\n    for (index = 0; index < notes.length; index += 1) if (notes[index].slot === lastSlot) { final = notes[index]; break; }\n    if (final) final.velocity = Math.max(final.velocity, 114);\n    else notes.push(note(roles[roles.length - 1], lastSlot, 114));\n  }\n\n  function densityCandidates(family, slots, rng) {\n    var source = DENSITY_CANDIDATES[family] || [['hat', 1], ['hat', 5], ['perc', 7], ['perc', 15]], shift, result = [], index, item;\n    shift = Math.floor(rng() * Math.max(1, Math.min(4, slots / 8))) * 2;\n    for (index = 0; index < source.length; index += 1) {\n      item = source[index];\n      result.push(note(item[0], (item[1] + (index % 2 ? shift : 0)) % slots, 44 + ((index * 7) % 25), 0));\n    }\n    return result;\n  }\n\n  function positionKey(item) { return item.role + ':' + item.slot; }\n\n  function applyDensity(family, notes, density, rng, slots) {\n    var fam = FAMILIES[family], anchors = {}, optional = [], candidates, amount, target, result, index, item, dropCount, sorted, dropped;\n    var i;\n    for (i = 0; i < ownKeys(fam.anchors).length; i += 1) {\n      var role = ownKeys(fam.anchors)[i], anchorList = fam.anchors[role], j;\n      for (j = 0; j < anchorList.length; j += 1) anchors[role + ':' + anchorList[j]] = true;\n    }\n    for (i = 0; i < notes.length; i += 1) {\n      if (!anchors[positionKey(notes[i])]) optional.push(notes[i]);\n    }\n    candidates = densityCandidates(family, slots, rng);\n    amount = clamp(density, 0, 100) / 100;\n    target = Math.round((optional.length + candidates.length) * (0.15 + amount * 0.95));\n    result = notes.slice();\n    if (optional.length > target) {\n      dropCount = optional.length - target; sorted = optional.slice().sort(function (a, b) { return a.velocity - b.velocity || a.slot - b.slot; });\n      dropped = {};\n      for (i = 0; i < dropCount; i += 1) dropped[positionKey(sorted[i])] = true;\n      result = [];\n      for (i = 0; i < notes.length; i += 1) if (anchors[positionKey(notes[i])] || !dropped[positionKey(notes[i])]) result.push(notes[i]);\n      return result;\n    }\n    if (optional.length < target && amount > 0.35) {\n      for (i = 0; i < candidates.length; i += 1) {\n        item = candidates[i];\n        if (result.filter(function (x) { return !anchors[positionKey(x)]; }).length >= target) break;\n        if (!hasPosition(result, item.role, item.slot)) result.push(item);\n      }\n    }\n    return result;\n  }\n\n  function applyFeel(notes, feel) {\n    var amount = (clamp(feel, 0, 100) / 100 - 0.5) * 0.5, index, item;\n    for (index = 0; index < notes.length; index += 1) {\n      item = notes[index];\n      if ((item.role === 'hat' || item.role === 'perc') && item.slot % 2 === 1) item.offset = clamp(item.offset + amount, -0.5, 0.5);\n    }\n  }\n\n  function humanize(notes, amount, rng) {\n    var scale = clamp(amount, 0, 100) / 100, index, item;\n    for (index = 0; index < notes.length; index += 1) {\n      item = notes[index];\n      item.offset = clamp(item.offset + (rng() * 2 - 1) * 0.3 * scale, -0.5, 0.5);\n      item.velocity = clamp(item.velocity + Math.round((rng() - 0.5) * 30 * scale), 1, 127);\n    }\n  }\n\n  function normalizeSettings(settings) {\n    var source = settings || {}, bars = integer(source.bars, 2), family = source.family || 'random', fill = source.fill || 'off';\n    if (FAMILY_KEYS.indexOf(family) === -1) family = 'random';\n    if (fill !== 'last' && fill !== 'every') fill = 'off';\n    return {\n      family: family, seed: source.seed === undefined ? 'rhythm-dice' : String(source.seed),\n      bars: Math.max(1, Math.min(4, bars)), density: clamp(source.density === undefined ? 50 : source.density, 0, 100),\n      feel: clamp(source.feel === undefined ? 50 : source.feel, 0, 100), humanize: clamp(source.humanize === undefined ? 30 : source.humanize, 0, 100), fill: fill\n    };\n  }\n\n  function roundTime(value) { return Math.round(value * 1000000) / 1000000; }\n\n  function toMidiNote(item, barStart, totalBeats) {\n    var duration = 0.2, maxStart = Math.max(0, totalBeats - duration), start = clamp(barStart + item.slot * 0.25 + item.offset * 0.25, 0, maxStart);\n    return {\n      pitch: DRUM_NOTES[item.role], start_time: roundTime(start), duration: duration,\n      velocity: Math.round(clamp(item.velocity, 1, 127)), mute: false, probability: 1,\n      velocity_deviation: 0, release_velocity: 64\n    };\n  }\n\n  function generatePattern(settings) {\n    var config = normalizeSettings(settings), familyRng = makeRng(config.seed, 'family'), family = config.family === 'random' ? pick(familyRng, FAMILY_KEYS) : config.family;\n    var fam = FAMILIES[family], meter = [fam.meter[0], fam.meter[1]], beatsPerBar = meter[0] * (4 / meter[1]), totalBeats = config.bars * beatsPerBar;\n    var fillBars = [], barStarts = [], notes = [], bar, slots, mode, generated, processed, index, barStart;\n    for (bar = 0; bar < config.bars; bar += 1) {\n      barStarts.push(bar * beatsPerBar);\n      mode = (config.fill === 'every' || (config.fill === 'last' && bar === config.bars - 1)) ? 'fill' : 'groove';\n      if (mode === 'fill') fillBars.push(bar);\n      slots = slotsForMeter(meter);\n      generated = fam.generate(makeRng(config.seed, family, mode, bar, meter.join('/')), slots, mode);\n      if (mode !== 'fill') addSeedMotif(generated, family, slots, makeRng(config.seed, 'motif', family, bar, meter.join('/')));\n      processed = applyDensity(family, generated, config.density, makeRng(config.seed, 'density', bar), slots);\n      applyFeel(processed, config.feel);\n      humanize(processed, config.humanize, makeRng(config.seed, 'humanize', bar));\n      barStart = barStarts[bar];\n      for (index = 0; index < processed.length; index += 1) notes.push(toMidiNote(processed[index], barStart, totalBeats));\n    }\n    notes.sort(function (a, b) { return a.start_time - b.start_time || a.pitch - b.pitch || a.velocity - b.velocity; });\n    return { notes: notes, family: family, meter: meter, bars: config.bars, totalBeats: totalBeats, barStarts: barStarts, fillBars: fillBars, settings: config };\n  }\n\n  function generate(settings) { return { notes: generatePattern(settings).notes }; }\n\n  function advanceSeed(seed) { return hashSeed(String(seed) + '|roll').toString(36); }\n\n  return {\n    DRUM_NOTES: DRUM_NOTES,\n    FAMILY_KEYS: FAMILY_KEYS,\n    FAMILIES: FAMILIES,\n    hashSeed: hashSeed,\n    makeRng: makeRng,\n    normalizeSettings: normalizeSettings,\n    generate: generate,\n    generatePattern: generatePattern,\n    advanceSeed: advanceSeed,\n    slotsForMeter: slotsForMeter\n  };\n}));\n\n/* Max wrapper appended to the portable core by the bundle build. */\nautowatch = 1;\ninlets = 2;\noutlets = 1;\n\nvar rdSettings = {\n  family: 'random', seed: 'rhythm-dice', bars: 2,\n  density: 50, feel: 50, humanize: 30, fill: 'off'\n};\nvar rdCore = (typeof RhythmDice !== 'undefined') ? RhythmDice : ((typeof module !== 'undefined') ? module.exports : null);\n\nfunction rdOutput() {\n  outlet_dictionary(0, rdCore.generate(rdSettings));\n}\n\n/* Max 9 v8 converts the incoming MIDI Tool Dict to a native JS object. */\nfunction msg_dictionary(value) { rdOutput(); }\nfunction bang() { rdOutput(); }\n\nfunction family(value) { rdSettings.family = value === undefined ? 'random' : String(value); }\nfunction family_index(value) { rdSettings.family = rdFamilyFromIndex(value); }\nfunction seed(value) { if (value !== undefined) rdSettings.seed = String(value); }\nfunction bars(value) { if (value !== undefined) rdSettings.bars = Number(value); }\nfunction bars_index(value) { rdSettings.bars = Number(value) + 1; }\nfunction density(value) { rdSettings.density = value; }\nfunction feel(value) { rdSettings.feel = value; }\nfunction humanize(value) { rdSettings.humanize = value; }\nfunction fill(value) { rdSettings.fill = String(value); }\nfunction fill_index(value) { rdSettings.fill = rdFillFromIndex(value); }\nfunction roll() { rdSettings.seed = rdCore.advanceSeed(rdSettings.seed); }\nfunction apply() { roll(); }\n\nfunction rdFamilyFromIndex(index) {\n  var i = Math.max(0, Math.min(rdCore.FAMILY_KEYS.length, Math.round(Number(index) || 0)));\n  return i === 0 ? 'random' : rdCore.FAMILY_KEYS[i - 1];\n}\nfunction rdFillFromIndex(index) {\n  var i = Math.round(Number(index) || 0);\n  return i === 1 ? 'last' : (i === 2 ? 'every' : 'off');\n}\n",
            "filename": "none",
            "flags": 0,
            "embed": 1,
            "autowatch": 1
          }
        }
      },
      {
        "box": {
          "id": "out",
          "maxclass": "newobj",
          "text": "live.miditool.out",
          "patching_rect": [
            420.0,
            350.0,
            112.0,
            22.0
          ]
        }
      },
      {
        "box": {
          "id": "transaction",
          "maxclass": "newobj",
          "text": "t b l",
          "patching_rect": [
            220.0,
            300.0,
            135.0,
            22.0
          ]
        }
      },
      {
        "box": {
          "id": "family-label",
          "maxclass": "comment",
          "text": "FAMILY",
          "patching_rect": [
            40.0,
            40.0,
            70.0,
            20.0
          ],
          "presentation": 1,
          "presentation_rect": [
            5.0,
            0.0,
            55.0,
            14.0
          ]
        }
      },
      {
        "box": {
          "id": "family",
          "maxclass": "live.menu",
          "numinlets": 1,
          "numoutlets": 3,
          "outlettype": [
            "",
            "",
            "float"
          ],
          "parameter_enable": 1,
          "patching_rect": [
            40.0,
            65.0,
            180.0,
            22.0
          ],
          "presentation": 1,
          "presentation_rect": [
            5.0,
            14.0,
            90.0,
            15.0
          ],
          "saved_attribute_attributes": {
            "valueof": {
              "parameter_enum": [
                "Random",
                "Crooked Pocket",
                "UK Swing",
                "Five-Count Break",
                "Dirty Machine",
                "Ghost Hardware",
                "Lo-fi Circuit",
                "Anchor + Ghosts",
                "Found-object Skeleton"
              ],
              "parameter_initial": [
                0
              ],
              "parameter_initial_enable": 1,
              "parameter_longname": "Rhythm Dice Family",
              "parameter_mmax": 8,
              "parameter_modmode": 0,
              "parameter_shortname": "Family",
              "parameter_type": 2
            }
          },
          "varname": "rdFamily"
        }
      },
      {
        "box": {
          "id": "family-pre",
          "maxclass": "newobj",
          "text": "prepend family_index",
          "patching_rect": [
            40.0,
            100.0,
            125.0,
            22.0
          ]
        }
      },
      {
        "box": {
          "id": "seed-label",
          "maxclass": "comment",
          "text": "SEED",
          "patching_rect": [
            240.0,
            40.0,
            60.0,
            20.0
          ],
          "presentation": 1,
          "presentation_rect": [
            5.0,
            31.0,
            40.0,
            14.0
          ]
        }
      },
      {
        "box": {
          "id": "seed",
          "maxclass": "live.numbox",
          "numinlets": 1,
          "numoutlets": 2,
          "outlettype": [
            "",
            "float"
          ],
          "parameter_enable": 1,
          "patching_rect": [
            240.0,
            65.0,
            120.0,
            22.0
          ],
          "presentation": 1,
          "presentation_rect": [
            5.0,
            45.0,
            65.0,
            15.0
          ],
          "saved_attribute_attributes": {
            "valueof": {
              "parameter_initial": [
                0
              ],
              "parameter_initial_enable": 1,
              "parameter_longname": "Rhythm Dice Seed",
              "parameter_mmax": 2147483647.0,
              "parameter_mmin": 0.0,
              "parameter_modmode": 4,
              "parameter_shortname": "Seed",
              "parameter_type": 0,
              "parameter_unitstyle": 0
            }
          },
          "varname": "rdSeed"
        }
      },
      {
        "box": {
          "id": "seed-pre",
          "maxclass": "newobj",
          "text": "prepend seed",
          "patching_rect": [
            240.0,
            100.0,
            85.0,
            22.0
          ]
        }
      },
      {
        "box": {
          "id": "bars-label",
          "maxclass": "comment",
          "text": "BARS",
          "patching_rect": [
            385.0,
            40.0,
            60.0,
            20.0
          ],
          "presentation": 1,
          "presentation_rect": [
            100.0,
            0.0,
            42.0,
            14.0
          ]
        }
      },
      {
        "box": {
          "id": "bars",
          "maxclass": "live.menu",
          "numinlets": 1,
          "numoutlets": 3,
          "outlettype": [
            "",
            "",
            "float"
          ],
          "parameter_enable": 1,
          "patching_rect": [
            385.0,
            65.0,
            75.0,
            22.0
          ],
          "presentation": 1,
          "presentation_rect": [
            100.0,
            14.0,
            43.0,
            15.0
          ],
          "saved_attribute_attributes": {
            "valueof": {
              "parameter_enum": [
                "1",
                "2",
                "3",
                "4"
              ],
              "parameter_initial": [
                1
              ],
              "parameter_initial_enable": 1,
              "parameter_longname": "Rhythm Dice Bars",
              "parameter_mmax": 3,
              "parameter_modmode": 0,
              "parameter_shortname": "Bars",
              "parameter_type": 2
            }
          },
          "varname": "rdBars"
        }
      },
      {
        "box": {
          "id": "bars-pre",
          "maxclass": "newobj",
          "text": "prepend bars_index",
          "patching_rect": [
            385.0,
            100.0,
            110.0,
            22.0
          ]
        }
      },
      {
        "box": {
          "id": "fill-label",
          "maxclass": "comment",
          "text": "FILL",
          "patching_rect": [
            520.0,
            40.0,
            50.0,
            20.0
          ],
          "presentation": 1,
          "presentation_rect": [
            75.0,
            31.0,
            35.0,
            14.0
          ]
        }
      },
      {
        "box": {
          "id": "fill",
          "maxclass": "live.menu",
          "numinlets": 1,
          "numoutlets": 3,
          "outlettype": [
            "",
            "",
            "float"
          ],
          "parameter_enable": 1,
          "patching_rect": [
            520.0,
            65.0,
            100.0,
            22.0
          ],
          "presentation": 1,
          "presentation_rect": [
            75.0,
            45.0,
            50.0,
            15.0
          ],
          "saved_attribute_attributes": {
            "valueof": {
              "parameter_enum": [
                "Off",
                "Last",
                "Every"
              ],
              "parameter_initial": [
                0
              ],
              "parameter_initial_enable": 1,
              "parameter_longname": "Rhythm Dice Fill",
              "parameter_mmax": 2,
              "parameter_modmode": 0,
              "parameter_shortname": "Fill",
              "parameter_type": 2
            }
          },
          "varname": "rdFill"
        }
      },
      {
        "box": {
          "id": "fill-pre",
          "maxclass": "newobj",
          "text": "prepend fill_index",
          "patching_rect": [
            520.0,
            100.0,
            105.0,
            22.0
          ]
        }
      },
      {
        "box": {
          "id": "density-label",
          "maxclass": "comment",
          "text": "DENSITY",
          "patching_rect": [
            40.0,
            165.0,
            80.0,
            20.0
          ],
          "presentation": 0,
          "presentation_rect": [
            5.0,
            65.0,
            45.0,
            14.0
          ]
        }
      },
      {
        "box": {
          "id": "density",
          "maxclass": "live.dial",
          "numinlets": 1,
          "numoutlets": 2,
          "outlettype": [
            "",
            "float"
          ],
          "parameter_enable": 1,
          "patching_rect": [
            40.0,
            190.0,
            55.0,
            55.0
          ],
          "presentation": 1,
          "presentation_rect": [
            5.0,
            64.0,
            44.0,
            50.0
          ],
          "saved_attribute_attributes": {
            "valueof": {
              "parameter_initial": [
                50.0
              ],
              "parameter_initial_enable": 1,
              "parameter_longname": "Rhythm Dice Density",
              "parameter_mmax": 100.0,
              "parameter_mmin": 0.0,
              "parameter_modmode": 3,
              "parameter_shortname": "Density",
              "parameter_type": 0,
              "parameter_unitstyle": 5
            }
          },
          "varname": "rdDensity"
        }
      },
      {
        "box": {
          "id": "density-pre",
          "maxclass": "newobj",
          "text": "prepend density",
          "patching_rect": [
            40.0,
            260.0,
            95.0,
            22.0
          ]
        }
      },
      {
        "box": {
          "id": "feel-label",
          "maxclass": "comment",
          "text": "FEEL",
          "patching_rect": [
            165.0,
            165.0,
            50.0,
            20.0
          ],
          "presentation": 0,
          "presentation_rect": [
            52.0,
            65.0,
            35.0,
            14.0
          ]
        }
      },
      {
        "box": {
          "id": "feel",
          "maxclass": "live.dial",
          "numinlets": 1,
          "numoutlets": 2,
          "outlettype": [
            "",
            "float"
          ],
          "parameter_enable": 1,
          "patching_rect": [
            165.0,
            190.0,
            55.0,
            55.0
          ],
          "presentation": 1,
          "presentation_rect": [
            53.0,
            64.0,
            44.0,
            50.0
          ],
          "saved_attribute_attributes": {
            "valueof": {
              "parameter_initial": [
                50.0
              ],
              "parameter_initial_enable": 1,
              "parameter_longname": "Rhythm Dice Feel",
              "parameter_mmax": 100.0,
              "parameter_mmin": 0.0,
              "parameter_modmode": 3,
              "parameter_shortname": "Feel",
              "parameter_type": 0,
              "parameter_unitstyle": 5
            }
          },
          "varname": "rdFeel"
        }
      },
      {
        "box": {
          "id": "feel-pre",
          "maxclass": "newobj",
          "text": "prepend feel",
          "patching_rect": [
            165.0,
            260.0,
            80.0,
            22.0
          ]
        }
      },
      {
        "box": {
          "id": "humanize-label",
          "maxclass": "comment",
          "text": "HUMAN",
          "patching_rect": [
            290.0,
            165.0,
            80.0,
            20.0
          ],
          "presentation": 0,
          "presentation_rect": [
            97.0,
            65.0,
            48.0,
            14.0
          ]
        }
      },
      {
        "box": {
          "id": "humanize",
          "maxclass": "live.dial",
          "numinlets": 1,
          "numoutlets": 2,
          "outlettype": [
            "",
            "float"
          ],
          "parameter_enable": 1,
          "patching_rect": [
            290.0,
            190.0,
            55.0,
            55.0
          ],
          "presentation": 1,
          "presentation_rect": [
            101.0,
            64.0,
            44.0,
            50.0
          ],
          "saved_attribute_attributes": {
            "valueof": {
              "parameter_initial": [
                30.0
              ],
              "parameter_initial_enable": 1,
              "parameter_longname": "Rhythm Dice Humanize",
              "parameter_mmax": 100.0,
              "parameter_mmin": 0.0,
              "parameter_modmode": 3,
              "parameter_shortname": "Human",
              "parameter_type": 0,
              "parameter_unitstyle": 5
            }
          },
          "varname": "rdHumanize"
        }
      },
      {
        "box": {
          "id": "humanize-pre",
          "maxclass": "newobj",
          "text": "prepend humanize",
          "patching_rect": [
            290.0,
            260.0,
            110.0,
            22.0
          ]
        }
      },
      {
        "box": {
          "id": "roll-button",
          "maxclass": "button",
          "numinlets": 1,
          "numoutlets": 1,
          "outlettype": [
            "bang"
          ],
          "patching_rect": [
            650.0,
            65.0,
            24.0,
            24.0
          ],
          "presentation": 0,
          "presentation_rect": [
            126.0,
            45.0,
            20.0,
            20.0
          ]
        }
      },
      {
        "box": {
          "id": "roll-label",
          "maxclass": "comment",
          "text": "⚄",
          "patching_rect": [
            685.0,
            65.0,
            80.0,
            20.0
          ],
          "presentation": 0,
          "presentation_rect": [
            126.0,
            31.0,
            20.0,
            14.0
          ]
        }
      },
      {
        "box": {
          "id": "roll",
          "maxclass": "message",
          "text": "roll",
          "patching_rect": [
            650.0,
            100.0,
            45.0,
            22.0
          ]
        }
      },
      {
        "box": {
          "id": "apply-button",
          "maxclass": "button",
          "numinlets": 1,
          "numoutlets": 1,
          "outlettype": [
            "bang"
          ],
          "patching_rect": [
            460.0,
            190.0,
            32.0,
            32.0
          ],
          "presentation": 1,
          "presentation_rect": [
            5.0,
            116.0,
            26.0,
            24.0
          ]
        }
      },
      {
        "box": {
          "id": "apply-label",
          "maxclass": "comment",
          "text": "ROLL THE DICE",
          "patching_rect": [
            505.0,
            196.0,
            145.0,
            20.0
          ],
          "presentation": 1,
          "presentation_rect": [
            36.0,
            119.0,
            105.0,
            18.0
          ]
        }
      },
      {
        "box": {
          "id": "dice-face",
          "maxclass": "panel",
          "patching_rect": [
            820.0,
            320.0,
            10.0,
            10.0
          ],
          "presentation": 1,
          "ignoreclick": 1,
          "border": 1,
          "bgfillcolor": [
            0.18,
            0.18,
            0.18,
            1.0
          ],
          "shape": 0,
          "presentation_rect": [
            5.0,
            115.0,
            26.0,
            26.0
          ],
          "rounded": 5,
          "bordercolor": [
            0.62,
            0.62,
            0.62,
            1.0
          ]
        }
      },
      {
        "box": {
          "id": "dice-pip-1",
          "maxclass": "panel",
          "patching_rect": [
            832.0,
            320.0,
            10.0,
            10.0
          ],
          "presentation": 1,
          "ignoreclick": 1,
          "border": 0,
          "bgfillcolor": [
            0.82,
            0.82,
            0.82,
            1.0
          ],
          "shape": 1,
          "presentation_rect": [
            10.0,
            120.0,
            4.0,
            4.0
          ]
        }
      },
      {
        "box": {
          "id": "dice-pip-2",
          "maxclass": "panel",
          "patching_rect": [
            844.0,
            320.0,
            10.0,
            10.0
          ],
          "presentation": 1,
          "ignoreclick": 1,
          "border": 0,
          "bgfillcolor": [
            0.82,
            0.82,
            0.82,
            1.0
          ],
          "shape": 1,
          "presentation_rect": [
            22.0,
            120.0,
            4.0,
            4.0
          ]
        }
      },
      {
        "box": {
          "id": "dice-pip-3",
          "maxclass": "panel",
          "patching_rect": [
            856.0,
            320.0,
            10.0,
            10.0
          ],
          "presentation": 1,
          "ignoreclick": 1,
          "border": 0,
          "bgfillcolor": [
            0.82,
            0.82,
            0.82,
            1.0
          ],
          "shape": 1,
          "presentation_rect": [
            16.0,
            126.0,
            4.0,
            4.0
          ]
        }
      },
      {
        "box": {
          "id": "dice-pip-4",
          "maxclass": "panel",
          "patching_rect": [
            868.0,
            320.0,
            10.0,
            10.0
          ],
          "presentation": 1,
          "ignoreclick": 1,
          "border": 0,
          "bgfillcolor": [
            0.82,
            0.82,
            0.82,
            1.0
          ],
          "shape": 1,
          "presentation_rect": [
            10.0,
            132.0,
            4.0,
            4.0
          ]
        }
      },
      {
        "box": {
          "id": "dice-pip-5",
          "maxclass": "panel",
          "patching_rect": [
            880.0,
            320.0,
            10.0,
            10.0
          ],
          "presentation": 1,
          "ignoreclick": 1,
          "border": 0,
          "bgfillcolor": [
            0.82,
            0.82,
            0.82,
            1.0
          ],
          "shape": 1,
          "presentation_rect": [
            22.0,
            132.0,
            4.0,
            4.0
          ]
        }
      }
    ],
    "lines": [
      {
        "patchline": {
          "source": [
            "in",
            0
          ],
          "destination": [
            "generator",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "generator",
            0
          ],
          "destination": [
            "out",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "transaction",
            1
          ],
          "destination": [
            "generator",
            1
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "transaction",
            0
          ],
          "destination": [
            "in",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "family",
            0
          ],
          "destination": [
            "family-pre",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "family-pre",
            0
          ],
          "destination": [
            "transaction",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "seed",
            0
          ],
          "destination": [
            "seed-pre",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "seed-pre",
            0
          ],
          "destination": [
            "transaction",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "bars",
            0
          ],
          "destination": [
            "bars-pre",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "bars-pre",
            0
          ],
          "destination": [
            "transaction",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "density",
            0
          ],
          "destination": [
            "density-pre",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "density-pre",
            0
          ],
          "destination": [
            "transaction",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "feel",
            0
          ],
          "destination": [
            "feel-pre",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "feel-pre",
            0
          ],
          "destination": [
            "transaction",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "humanize",
            0
          ],
          "destination": [
            "humanize-pre",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "humanize-pre",
            0
          ],
          "destination": [
            "transaction",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "fill",
            0
          ],
          "destination": [
            "fill-pre",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "fill-pre",
            0
          ],
          "destination": [
            "transaction",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "roll-button",
            0
          ],
          "destination": [
            "roll",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "roll",
            0
          ],
          "destination": [
            "transaction",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "apply-button",
            0
          ],
          "destination": [
            "roll",
            0
          ]
        }
      }
    ],
    "parameters": {
      "family": [
        "Rhythm Dice Family",
        "Family",
        0
      ],
      "seed": [
        "Rhythm Dice Seed",
        "Seed",
        0
      ],
      "bars": [
        "Rhythm Dice Bars",
        "Bars",
        0
      ],
      "density": [
        "Rhythm Dice Density",
        "Density",
        0
      ],
      "feel": [
        "Rhythm Dice Feel",
        "Feel",
        0
      ],
      "humanize": [
        "Rhythm Dice Humanize",
        "Human",
        0
      ],
      "fill": [
        "Rhythm Dice Fill",
        "Fill",
        0
      ],
      "parameterbanks": {
        "0": {
          "index": 0,
          "name": "",
          "parameters": [
            "family",
            "seed",
            "bars",
            "density",
            "feel",
            "humanize",
            "fill",
            "-"
          ]
        }
      },
      "inherited_shortname": 1
    },
    "dependency_cache": []
  }
}
