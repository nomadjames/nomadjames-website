const test = require('node:test');
const assert = require('node:assert/strict');
const {
  DRUM_NOTES,
  FAMILY_KEYS,
  FAMILIES,
  generate,
  generatePattern,
  advanceSeed,
} = require('../src/rhythm-dice.js');

function signature(result) {
  return JSON.stringify(result.notes);
}

function anchorHit(result, role, slot, bar) {
  const pitch = DRUM_NOTES[role];
  const start = result.barStarts[bar] + slot * 0.25;
  return result.notes.some((note) => note.pitch === pitch && Math.abs(note.start_time - start) < 0.13);
}

test('same explicit seed and settings produce identical MIDI-tool notes', () => {
  const settings = { family: 'crooked-pocket', seed: 'alpha-17', bars: 3, density: 63, feel: 72, humanize: 41, fill: 'last' };
  assert.deepEqual(generate(settings), generate(settings));
  assert.equal(signature(generatePattern(settings)), signature(generatePattern(settings)));
});

test('all eight families are selectable and preserve their declared anchors', () => {
  assert.equal(FAMILY_KEYS.length, 8);
  for (const family of FAMILY_KEYS) {
    const result = generatePattern({ family, seed: 'family-anchor', bars: 1, density: 50, feel: 50, humanize: 0 });
    const info = FAMILIES[family];
    for (const role of Object.keys(info.anchors)) {
      for (const slot of info.anchors[role]) {
        assert.equal(anchorHit(result, role, slot, 0), true, `${family} missing ${role} anchor ${slot}`);
      }
    }
  }
});

test('bars 1 through 4 use exact 4/4 total lengths', () => {
  for (let bars = 1; bars <= 4; bars += 1) {
    const result = generatePattern({ family: 'dirty-machine', seed: 'bar-count', bars, humanize: 100 });
    assert.equal(result.totalBeats, bars * 4);
    assert.equal(result.barStarts.length, bars);
    for (const note of result.notes) {
      assert.ok(note.start_time >= 0);
      assert.ok(note.start_time + note.duration <= result.totalBeats + 1e-9);
    }
  }
});

test('five-count-break uses true 5/4 timing across multiple bars', () => {
  const result = generatePattern({ family: 'five-count-break', seed: 'five', bars: 4, humanize: 100 });
  assert.deepEqual(result.meter, [5, 4]);
  assert.deepEqual(result.barStarts, [0, 5, 10, 15]);
  assert.equal(result.totalBeats, 20);
  assert.equal(anchorHit(result, 'snare', 8, 2), true);
  for (const note of result.notes) assert.ok(note.start_time + note.duration <= 20 + 1e-9);
});

test('changing the explicit seed changes the generated pattern', () => {
  const a = generatePattern({ family: 'anchor-ghosts', seed: 'seed-a', bars: 2, density: 50, humanize: 0 });
  const b = generatePattern({ family: 'anchor-ghosts', seed: 'seed-b', bars: 2, density: 50, humanize: 0 });
  assert.notEqual(signature(a), signature(b));
});

test('roll advances the seed deterministically without wall-clock time', () => {
  const first = advanceSeed('rhythm-dice');
  assert.equal(first, advanceSeed('rhythm-dice'));
  assert.notEqual(first, 'rhythm-dice');
  assert.notEqual(advanceSeed(first), first);
});

test('density preserves anchors and changes note count meaningfully', () => {
  const low = generatePattern({ family: 'found-object-skeleton', seed: 'density', bars: 2, density: 0, humanize: 0 });
  const high = generatePattern({ family: 'found-object-skeleton', seed: 'density', bars: 2, density: 100, humanize: 0 });
  assert.ok(high.notes.length > low.notes.length, `${low.notes.length} vs ${high.notes.length}`);
  assert.equal(anchorHit(low, 'kick', 0, 0), true);
  assert.equal(anchorHit(low, 'snare', 8, 0), true);
  assert.equal(anchorHit(high, 'kick', 0, 1), true);
  assert.equal(anchorHit(high, 'snare', 8, 1), true);
});

test('feel changes off-grid offsets without changing the deterministic base', () => {
  const straight = generatePattern({ family: 'uk-swing', seed: 'feel', bars: 1, density: 60, feel: 0, humanize: 0 });
  const laidback = generatePattern({ family: 'uk-swing', seed: 'feel', bars: 1, density: 60, feel: 100, humanize: 0 });
  assert.notEqual(signature(straight), signature(laidback));
  assert.ok(straight.notes.some((note) => note.start_time % 0.5 !== 0));
});

test('humanize changes timing and velocity but never accumulates drift', () => {
  const clean = generatePattern({ family: 'ghost-hardware', seed: 'human', bars: 3, density: 55, feel: 50, humanize: 0 });
  const human = generatePattern({ family: 'ghost-hardware', seed: 'human', bars: 3, density: 55, feel: 50, humanize: 80 });
  assert.notEqual(signature(clean), signature(human));
  assert.deepEqual(human, generatePattern({ family: 'ghost-hardware', seed: 'human', bars: 3, density: 55, feel: 50, humanize: 80 }));
  assert.deepEqual(clean, generatePattern({ family: 'ghost-hardware', seed: 'human', bars: 3, density: 55, feel: 50, humanize: 0 }));
});

test('last and every fill modes shape the requested bars', () => {
  const last = generatePattern({ family: 'lo-fi-circuit', seed: 'fill', bars: 3, density: 45, fill: 'last', humanize: 0 });
  const every = generatePattern({ family: 'lo-fi-circuit', seed: 'fill', bars: 3, density: 45, fill: 'every', humanize: 0 });
  assert.notEqual(signature(last), signature(every));
  assert.deepEqual(last.fillBars, [2]);
  assert.deepEqual(every.fillBars, [0, 1, 2]);
  assert.ok(last.notes.some((note) => note.start_time >= 11.75 && note.velocity >= 114));
});

test('generated dictionaries use the official safe note schema and legal ranges', () => {
  const result = generate({ family: 'random', seed: 'schema', bars: 4, density: 100, feel: 100, humanize: 100, fill: 'every' });
  assert.deepEqual(Object.keys(result), ['notes']);
  assert.ok(result.notes.length > 0);
  for (const note of result.notes) {
    assert.deepEqual(Object.keys(note), [
      'pitch', 'start_time', 'duration', 'velocity', 'mute', 'probability', 'velocity_deviation', 'release_velocity',
    ]);
    assert.ok(Number.isInteger(note.pitch) && note.pitch >= 0 && note.pitch <= 127);
    assert.ok(note.start_time >= 0 && note.duration > 0 && note.start_time + note.duration <= 16 + 1e-9);
    assert.ok(Number.isInteger(note.velocity) && note.velocity >= 1 && note.velocity <= 127);
    assert.equal(note.mute, false);
    assert.equal(note.probability, 1);
    assert.equal(note.velocity_deviation, 0);
    assert.ok(Number.isInteger(note.release_velocity));
  }
  assert.deepEqual(Object.values(DRUM_NOTES).sort((a, b) => a - b), [36, 38, 39, 42]);
});

test('settings are bounded and random family selection remains deterministic', () => {
  const a = generatePattern({ family: 'random', seed: 'random-family', bars: 99, density: -20, feel: 200, humanize: -2 });
  const b = generatePattern({ family: 'random', seed: 'random-family', bars: 4, density: 0, feel: 100, humanize: 0 });
  assert.equal(a.family, b.family);
  assert.equal(a.bars, 4);
  assert.equal(a.totalBeats, 4 * (a.meter[0]));
});
