'use strict';

var test = require('node:test');
var assert = require('node:assert/strict');
var fs = require('node:fs');
var path = require('node:path');
var vm = require('node:vm');

function loadWrapper() {
  var outputs = [];
  var dictionaries = {};
  var serial = 0;

  function MockDict(name) {
    this.name = name || ('mock-dict-' + (++serial));
    dictionaries[this.name] = this;
  }
  MockDict.prototype.parse = function (source) {
    this.value = typeof source === 'string' ? JSON.parse(source) : source;
  };

  var context = {
    Dict: MockDict,
    outlet: function () { outputs.push(Array.prototype.slice.call(arguments)); },
    outlet_dictionary: function (index, value) { outputs.push([index, 'dictionary-object', value]); },
    arrayfromargs: function (args) { return Array.prototype.slice.call(args); },
    Math: Math,
    JSON: JSON,
    Number: Number,
    String: String,
    Object: Object,
    Array: Array,
    isFinite: isFinite,
  };
  vm.createContext(context);
  vm.runInContext(
    fs.readFileSync(path.join(__dirname, '../max/rd_generator.js'), 'utf8'),
    context,
    { filename: 'rd_generator.js' }
  );
  return { context: context, outputs: outputs, dictionaries: dictionaries };
}

function setting(wrapper, name, value) {
  var handler = wrapper.context[name];
  assert.equal(typeof handler, 'function', 'missing Max message handler: ' + name);
  handler(value);
}

function emittedDictionary(wrapper, index) {
  var message = wrapper.outputs[index];
  assert.equal(message[0], 0);
  assert.equal(message[1], 'dictionary-object');
  return message[2];
}

test('Max wrapper stores controls without writing outside a MIDI Tool transaction', function () {
  var wrapper = loadWrapper();
  setting(wrapper, 'family_index', 4);
  setting(wrapper, 'bars_index', 2);
  setting(wrapper, 'density', 75);
  setting(wrapper, 'feel', 30);
  setting(wrapper, 'humanize', 45);
  setting(wrapper, 'fill_index', 1);
  assert.equal(wrapper.context.rdSettings.family, 'dirty-machine');
  assert.equal(wrapper.context.rdSettings.bars, 3);
  assert.equal(wrapper.context.rdSettings.density, 75);
  assert.equal(wrapper.context.rdSettings.feel, 30);
  assert.equal(wrapper.context.rdSettings.humanize, 45);
  assert.equal(wrapper.context.rdSettings.fill, 'last');
  assert.equal(wrapper.outputs.length, 0);

  wrapper.context.msg_dictionary({ notes: [] });
  assert.equal(wrapper.outputs.length, 1);
  var result = emittedDictionary(wrapper, 0);
  assert.ok(Array.isArray(result.notes));
  assert.ok(result.notes.length > 0);
});

test('every input transaction emits one dictionary and roll changes the result', function () {
  var wrapper = loadWrapper();
  wrapper.context.bang();
  assert.equal(wrapper.outputs.length, 1);
  var before = emittedDictionary(wrapper, 0);

  setting(wrapper, 'roll');
  assert.equal(wrapper.outputs.length, 1, 'roll must wait for live.miditool.in');

  wrapper.context.msg_dictionary({ notes: [] });
  assert.equal(wrapper.outputs.length, 2);
  var after = emittedDictionary(wrapper, 1);
  assert.notDeepEqual(after.notes, before.notes);
});
